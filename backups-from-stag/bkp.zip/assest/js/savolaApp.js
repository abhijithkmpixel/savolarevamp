const api_user = "SAVOLA-GROUP"; //Argaam API User
const api_password = "B88S21-US8A71C4CF74223C857BE8F-A0009F-1D"; // Argaam API Password

const baseUrl = "https://data.argaam.com";
const api_version = "1.0";

const formatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 1,
    maximumFractionDigits: 2,
});

const largeFormatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 3,
    maximumFractionDigits: 3,
});

const toRealNumber = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
});

var savolaApp = new Vue({
    Config: appConfig,

    el: "#SavolaApp",
    data: {
        _token: "",
        accessTokenExpireIn: new Date(2020),

        Config: appConfig,

        companyId: 85, //this will be set by accesstoken
        marketId: 3,
        Language: "en",

        Loading: {},
        PageLoading: false,

        CompanyOverview: {
            stockChanges: {
                ForDate: "2021-11-14T00:00:00",
                "1DPercentage": 0.0,
                "1DChange": 0,
                "5DPercentage": 0.0,
                "5DChange": 0.0,
                "1MPercentage": 0.0,
                "1MChnage": 0.0,
                "3MPercentage": 0.0,
                "3MChnage": 0.0,
                "6MPercentage": 0.0,
                "6MChanges": 0.0,
                "1YPercentage": 0.0,
                "1YChange": 0.0,
                YTDPercentage: 0.0,
                YTDChange: 0.0,
                "2YPercentage": 0.0,
                "2YChange": 0.0,
                "5YPercentage": 0.0,
                "5YChange": 0.0,
                YAPercentage: 0.0,
                YAChange: 0.0,
            },
            prices: [
                {
                    marketID: 0,
                    companyID: 0,
                    bid: "",
                    tradingDate: "",
                    openValue: 0,
                    closeValue: 0,
                    previousCloseValue: 0,
                    high: 0,
                    low: 0,
                    change: 0,
                    volume: 0,
                    amount: 0,
                    percentageChange: 0,
                },
            ],
            profileInfo: {
                companyID: 0,
                marketID: 0,
                bid: "",
                companyNameAr: "",
                companyNameEn: "",
                cityNameEn: "",
                cityNameAr: "",
                addressEn: "",
                addressAr: "",
                poBoxEn: "",
                phone: "",
                fax: "",
                poBoxAr: "",
                email: "",
                websiteURL: "",
                summaryEn: "",
                summaryAr: "",
                overviewEn: "",
                overviewAr: "",
                ticker: "",
            },
            events: [
                {
                    calendarEventID: 0,
                    marketID: 0,
                    companyID: 0,
                    occursOn: "2021-08-29T10:20:30.482Z",
                    titleEn: "",
                    titleAr: "",
                    descriptionEn: "",
                    descriptionAr: "",
                    calendarEventTypeID: 0,
                    eventLocationAr: "",
                    eventLocationEn: "",
                    articleLinkURLAr: "",
                    articleLinkURLEn: "",
                    latitude: "",
                    longitude: "",
                },
            ],
            financialResultPdf: {
                companyNameEn: "",
                companyNameAr: "",
                company: 0,
                year: 0,
                files: [
                    {
                        year: 0,
                        fiscalPeriod: "",
                        fileURLAr: "",
                        fileURLEn: "",
                    },
                ],
                marketID: 0,
            },
            financialRatios: {
                period: "",
                forYear: 0,
                fields: [
                    {
                        ratioName: "",
                        nameEn: "",
                        nameAr: "",
                        values: {
                            year: "",
                            period: "",
                            value: "",
                        },
                    },
                ],
            },
            discloser: [
                {
                    articleID: 0,
                    languageID: 0,
                    language: "",
                    title: "",
                    publishedOn: "",
                    link: "",
                    isLinked: true,
                    linkedToURL: "",
                    isPaid: true,
                    articleSourceName: "",
                    articleType: "",
                    articleTypeNameAr: "",
                    articleTypeNameEn: "",
                    marketTickerIDs: "",
                    showDetails: false,
                    body: "<span>Loading...</span>",
                    marketTickerChartIDs: [""],
                    companyTickerIDs: "",
                    companyTickerChartIDs: [""],
                },
            ],
            latestNews: [
                {
                    articleID: 0,
                    languageID: 0,
                    language: "",
                    title: "",
                    publishedOn: "",
                    link: "",
                    isLinked: true,
                    linkedToURL: "",
                    isPaid: true,
                    articleSourceName: "",
                    articleType: "",
                    articleTypeNameAr: "",
                    articleTypeNameEn: "",
                    marketTickerIDs: "",
                    showDetails: false,
                    marketTickerChartIDs: [""],
                    companyTickerIDs: "",
                    body: "<span>Loading...</span>",
                    companyTickerChartIDs: [""],
                },
            ],
            argaamReports: [
                {
                    articleID: 0,
                    languageID: 0,
                    language: "",
                    title: "",
                    publishedOn: "",
                    link: "",
                    isLinked: true,
                    linkedToURL: "",
                    isPaid: true,
                    articleSourceName: "",
                    articleType: "",
                    articleTypeNameAr: "",
                    articleTypeNameEn: "",
                    marketTickerIDs: "",
                    showDetails: false,
                    body: "<span>Loading...</span>",
                    marketTickerChartIDs: [""],
                    companyTickerIDs: "",
                    companyTickerChartIDs: [""],
                },
            ],
            analystEstimates: [
                {
                    articleID: 0,
                    languageID: 0,
                    language: "",
                    title: "",
                    publishedOn: "",
                    link: "",
                    isLinked: true,
                    linkedToURL: "",
                    isPaid: true,
                    articleSourceName: "",
                    articleType: "",
                    showDetails: false,
                    articleTypeNameAr: "",
                    articleTypeNameEn: "",
                    marketTickerIDs: "",
                    body: "<span>Loading...</span>",
                    marketTickerChartIDs: [""],
                    companyTickerIDs: "",
                    companyTickerChartIDs: [""],
                },
            ],
            companyStockSummary: {
                companyStockPriceID: 0,
                companyID: 0,
                companyNameEn: "",
                companyNameAr: "",
                marketID: 0,
                marketNameEn: "",
                marketNameAr: "",
                sectorID: 0,
                sectorNameEn: "",
                sectorNameAr: "",
                marketStatusID: 0,
                defaultMarketID: 0,
                forDate: "2021-08-29T10:20:30.483Z",
                recordStatus: 0,
                displaySeqNo: 0,
                openValue: 0,
                closeValue: 0,
                dailyClose: 0,
                previousCloseValue: 0,
                high: 0,
                low: 0,
                indexValue: 0,
                change: 0,
                percentageChange: 0,
                volume: 0,
                amount: 0,
                contractCount: 0,
                avgVolume3Months: 0,
                avgTransactions3Months: 0,
                highPrice52weeks: 0,
                lowPrice52weeks: 0,
                y2TDChange: 0,
                ytdChange: 0,
                month6Change: 0,
                month3Change: 0,
                month2Change: 0,
                month1Change: 0,
                weekChange: 0,
                ybgnChange: 0,
                y2TDFirstChange: 0,
                y2TDFirstDate: "2021-08-29T10:20:30.483Z",
                lastProcessedEntryNo: 0,
                avgVolume12Months: 0,
                avgTransactions12Months: 0,
                avgTurnover12Months: 0,
                avgTurnover3Months: 0,
                groupID: 0,
                groupCompaniesID: 0,
                shortNameAr: "",
                shortNameEn: "",
                marketValue: 0,
            },
            dividandInfo: {
                totalRecords: 0,
                companyDividendInformationID: 0,
                companyID: 0,
                capital: 0.0,
                dividendDate: "2021-08-29T10:20:30.483Z",
                dividendAnnouncedDate: "2021-08-29T10:20:30.483Z",
                dividendDueDate: "2021-08-29T10:20:30.483Z",
                companyDividendStatusID: 0,
                cashDividend: 0,
                bonusShareDistributed: 0,
                dividendPercentage: 0,
                notesEn: "",
                notesAr: "",
                createdOn: "2021-08-29T10:20:30.483Z",
                dividendPolicy: "",
                companyDividendStatusNameEn: "",
                companyDividendStatusNameAr: "",
                numberOfShares: 0,
                cashDividendPerShare: 0,
                measuringUnitNameAr: "",
                measuringUnitNameEn: "",
                currencyNameAr: "",
                currencyNameEn: "",
                fundSize: 0,
                sectorID: 0,
            },
            cpaitalSummary: {
                companyCapitalID: 0,
                companyID: 0,
                marketID: 0,
                companyCapitalStatusID: 0,
                currentCapital: 0,
                currentShares: 0,
                bonusShares: 0,
                announcedDate: "2021-08-29T10:20:30.483Z",
                dueDate: "2021-08-29T10:20:30.483Z",
                splitDate: "2021-08-29T10:20:30.483Z",
                notesAr: "",
                notesEn: "",
                linkAr: "",
                linkEn: "",
                newCapital: 0,
                newShares: 0,
                measuringUnitID: 0,
                currencyID: 0,
                companyCapitalStatusNameAr: "",
                companyCapitalStatusNameEn: "",
                measuringUnitNameAr: "",
                measuringUnitNameEn: "",
                currencyNameAr: "",
                currencyNameEn: "",
            },
        },
        CompanyProfile: {
            profileInfo: {
                companyID: 0,
                marketID: 0,
                bid: "",
                companyNameAr: "",
                companyNameEn: "",
                cityNameEn: "",
                cityNameAr: "",
                addressEn: "",
                addressAr: "",
                poBoxEn: "",
                phone: "",
                fax: "",
                poBoxAr: "",
                email: "",
                websiteURL: "",
                summaryEn: "",
                summaryAr: "",
                overviewEn: "",
                overviewAr: "",
                ticker: "",
            },
            financialHighlights: [
                {
                    CompanyID: 0,
                    FSFieldName: "",
                    DisplayNameAr: "",
                    DisplayNameEn: "",
                    IsCurrency: false,
                    Currency: "SAR",
                    2020: 0,
                    2019: 0,
                    2018: 0,
                    2017: 0,
                    2016: 0,
                },
            ],
            tradingData: {
                freeFloatedShareID: 0,
                companyID: 0,
                marketID: 0,
                measuringUnitID: 0,
                freeFloatShareValue: 0,
                announcedDate: "2021-08-30T13:10:44.806Z",
                fiscalPeriodID: 0,
                isDeleted: true,
                createdOn: "2021-08-30T13:10:44.806Z",
                createdBy: 0,
                updatedOn: "2021-08-30T13:10:44.806Z",
                updatedBy: 0,
                totalItems: 0,
                totalCompanies: 0,
                companyName: "",
                measuringUnit: "",
                marketName: "",
                aggregatedValues: 0,
                sectorName: "",
                gicsSectorName: "",
                numberOfShares: 0,
                numberOfFreeShares: 0,
                percentage: 0,
                freeFloatedShareMarketValue: 0,
                companyWeight: 0,
                companyNameEn: "",
                companyNameAr: "",
                shortNameAr: "",
                shortNameEn: "",
                measuringUnitNameAr: "",
                measuringUnitNameEn: "",
                freeFloatedShareValues: "",
                year: 0,
                month: 0,
                sectorID: 0,
                date: "",
                hasOnlyBasicProfile: true,
                yearEndMonth: 0,
                avgTransactions3Months: 0,
                avgVolume3Months: 0,
                marketNameAr: "",
                marketNameEn: "",
                foreignOwnerShip: 0,
            },
            stockInfo: {
                companyID: 0,
                viewCount: 0,
                addressEn: "",
                addressAr: "",
                establishedOn: "",
                establishedOnDay: 0,
                establishedOnMonth: 0,
                establishedOnYear: 0,
                poBoxEn: "",
                poBoxAr: "",
                email: "",
                websiteURL: "",
                summaryEn: "",
                summaryAr: "",
                overviewEn: "",
                overviewAr: "",
                createdOn: "2021-08-30T13:10:44.806Z",
                updatedOn: "2021-08-30T13:10:44.806Z",
                phone: "",
                fax: "",
                numberOfShares: 0,
                numberOfSharesMeasuringUnitID: 0,
                nominalValue: 0,
                nominalValueMeasuringUnitID: 0,
                businessSegmentOverviewAr: "",
                businessSegmentOverviewEn: "",
                geoLocationSegmentOverviewEn: "",
                geoLocationSegmentOverviewAr: "",
                fiscalPeriodStartMonth: 0,
                foreignOwnerShip: 0,
                dividends: 0,
                marketValue: 0,
                bookValue: 0,
            },
            majorShareholder: [
                {
                    shareholderID: 0,
                    shareholderNameAr: "",
                    shareholderNameEn: "",
                    shareholderTypeNameAr: "",
                    shareholderTypeNameEn: "",
                    noOfShares: 0,
                    marketValue: 0,
                    percentage: 0,
                    notesAr: "",
                    notesEn: "",
                },
            ],
            milestones: [
                {
                    companyID: 0,
                    titleAr: "",
                    titleEn: "",
                    developmentDay: 0,
                    developmentMonth: 0,
                    developmentYear: 0,
                    fullDate: "",
                    articleLinkAr: "",
                    articleLinkEn: "",
                    totalRecords: "",
                },
            ],
        },
        CompanyChart: {
            fromDate: "",
            toDate: "",
            chartsData: [
                {
                    totalRecords: 0,
                    change: 0,
                    percentageChange: 0,
                    forTime: "",
                    companyStockPriceArchiveID: 0,
                    forDate: "",
                    tcCompanyID: 0,
                    companyID: 0,
                    entryNumber: 0,
                    volume: 0,
                    amount: 0,
                    open: 0,
                    close: 0,
                    min: 0,
                    max: 0,
                    contractCount: 0,
                    tcMarketID: 0,
                    marketID: 0
                }
            ]
        },
        chartData: [],
        CompanyInvestorPresentations: {
            reportTypeID: "",
            dateFrom: "",
            dateTo: "",
            InvestorsPresentations: [
                {
                    companyID: 0,
                    descriptionEn: "",
                    descriptionAr: "",
                    attachLinkUrlAr: "",
                    attachLinkUrlEn: "",
                    typeNameAr: "",
                    typeNameEn: "",
                    createdOn: ""
                }
            ]
        },
        CompanyBusinessSegments: {
            fiscalPeriodType: "year",
            currency: 'riyal',
            businessSegmentsDefinitions: [
                {
                    businessSegmentID: 0,
                    businessSegmentNameAr: "",
                    businessSegmentNameEn: "",
                    definitionAr: "",
                    definitionEn: ""
                }
            ],
            fsFields: [
                {
                    fsFieldID: 0,
                    fsFieldNameAr: "",
                    fsFieldNameEn: "",
                    businessSegments: [
                        {
                            businessSegmentNameAr: "",
                            businessSegmentNameEn: "",
                            periodicValues: [
                                {
                                    forDate: "",
                                    value: 0
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        CompanyGeolocationSegments: {
            fiscalPeriodType: "year",
            currency: 'riyal',
            geoLocationSegmentsDefinitions: [
                {
                    geoLocationSegmentID: 0,
                    geoLocationSegmentNameAr: "",
                    geoLocationSegmentNameEn: "",
                    definitionAr: "",
                    definitionEn: ""
                }
            ],
            fsFields: [
                {
                    fsFieldID: 0,
                    fsFieldNameAr: "",
                    fsFieldNameEn: "",
                    geoLocationSegments: [
                        {
                            geoLocationSegmentNameAr: "",
                            geoLocationSegmentNameEn: "",
                            periodicValues: [
                                {
                                    forDate: "",
                                    value: 0
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        CompanyAnalystOpinions: {
            "analystOpinions": [
                {
                    "forDate": "",
                    "brokerID": 0,
                    "brokerNameAr": "",
                    "brokerNameEn": "",
                    "currentOpinionAr": "",
                    "currentOpinionEn": " ",
                    "previousOpinionAr": "",
                    "previousOpinionEn": "",
                    "currentPrice": 0,
                    "targetPrice": 0,
                    "change": 0,
                    "attachLinkURLAr": "",
                    "attachLinkURLEn": ""
                }
            ]
        },
        CompanyAnalystEstimates: {
            fiscalPeriodType: "",
            "tabs": [
                {
                    "fsFieldCategoryID": 0,
                    "fsFieldCategoryNameAr": "",
                    "fsFieldCategoryNameEn": "",
                    "fieldsValues": [
                        {
                            "fsFieldID": 0,
                            "fsFieldNameAr": "",
                            "fsFieldNameEn": "",
                            "periodValues": [
                                {
                                    "forYear": 0,
                                    "fiscalPeriodValue": "",
                                    "forDate": "",
                                    "estimatedValue": 0,
                                    "actualValue": 0
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        CompanyMergerAcquisitions: [
            {
                "mergerID": 0,
                "announcedOn": "",
                "acquisitionValue": 0,
                "acquisitionValueCurrency": "Million USD",
                "acquisitionTypeNameAr": "",
                "acquisitionTypeNameEn": "",
                "acquisitionStatusNameAr": "",
                "acquisitionStatusNameEn": "",
                "acquirers": [
                    {
                        "companyID": 0,
                        "companyNameAr": "",
                        "companyNameEn": ""
                    }
                ],
                "targets": [
                    {
                        "companyID": 0,
                        "companyNameAr": "",
                        "companyNameEn": ""
                    }
                ],
                "relatedCompanies": [
                    {
                        "companyID": 0,
                        "companyNameAr": "",
                        "companyNameEn": ""
                    }
                ]
            }
        ],
        CompanyFStatements: {
            companyFinancialResults: [
                {
                    companyID: 0,
                    fileURLAr: "#",
                    fileURLEn: "#",
                    fiscalPeriodValueID: 0,
                    forYear: 0
                }
            ],
            tabs: [
                {
                    tabNameEn: "",
                    tabNameAr: "",
                    fields: [
                        {
                            displayNameEn: "",
                            displayNameAr: "",
                            isCurrency: false,
                            currency: '',
                            values: [
                                {
                                    forYear: 0,
                                    fiscalPeriodValueID: 0,
                                    fiscalPeriod: "",
                                    forDate: "",
                                    value: 0
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        FinancialResults: {
            financialResults: [
                {
                    year: 0,
                    q1en: "",
                    q1ar: "",
                    q2en: "",
                    q2ar: "",
                    q3en: "",
                    q3ar: "",
                    q4en: "",
                    q4ar: "",
                    annualen: "",
                    annualar: "",
                    managementen: "",
                    managementar: ""
                }
            ]
        },
        CompanyFRatios: {
            financialRatioFieldsGroups: [
                {
                    fieldGroupAr: "",
                    fieldGroupEn: "",
                    groupSeqNo: 0,
                    financialRatioFieldsGroupFields: [
                        {
                            ratioName: "",
                            nameEn: "",
                            nameAr: "",
                            isCurrency: false,
                            currency: '',
                            values: [
                                {
                                    year: "",
                                    period: "",
                                    value: ""
                                }
                            ]
                        }
                    ]
                }
            ]
        },
        CorporateActions: {
            recentDividends: {
                totalRecords: 0,
                companyDividendInformationID: 0,
                companyID: 0,
                dividendDate: "",
                dividendAnnouncedDate: "",
                dividendDueDate: "",
                companyDividendStatusID: 0,
                cashDividend: 0,
                bonusShareDistributed: 0,
                dividendPercentage: 0,
                notesEn: "",
                notesAr: "",
                createdOn: "",
                dividendPolicy: "",
                companyDividendStatusNameEn: "",
                companyDividendStatusNameAr: "",
                numberOfShares: 0,
                cashDividendPerShare: 0,
                measuringUnitNameAr: "",
                measuringUnitNameEn: "",
                currencyNameAr: "",
                currencyNameEn: "",
                fundSize: 0,
                sectorID: 0
            },
            capitalChanges: {
                companyCapitalStatusNameAr: "",
                companyCapitalStatusNameEn: "",
                measuringUnitNameAr: "",
                measuringUnitNameEn: "",
                currencyNameAr: "",
                currencyNameEn: "",
                companyCapitalID: 0,
                companyID: 0,
                marketID: 0,
                companyCapitalStatusID: 0,
                currentCapital: 0,
                currentShares: 0,
                bonusShares: 0,
                announcedDate: "",
                dueDate: "",
                splitDate: "",
                notesAr: "",
                notesEn: "",
                linkAr: "",
                linkEn: "",
                newCapital: 0,
                newShares: 0,
                measuringUnitID: 0,
                currencyID: 0
            },
            capitalChangeHistory: [
                {
                    ipoid: 0,
                    companyID: 0,
                    tableDate: "",
                    typeEn: "",
                    typeAr: "",
                    currentCapital: 0,
                    currentShares: 0,
                    newCapital: 0,
                    newShares: 0,
                    offeredPercentage: 0,
                    changeRate: 0,
                    notesAr: "",
                    notesEn: "",
                    linkAr: "",
                    conditionalLinkAr: "",
                    linkEn: "",
                    conditionalLinkEn: "",
                    ipoStatusID: 0,
                    statusNameAr: "",
                    statusNameEn: ""
                }
            ],
            capitalDividendHistory: [
                {
                    totalRecords: 0,
                    companyDividendInformationID: 0,
                    companyID: 0,
                    dividendDate: "",
                    dividendAnnouncedDate: "",
                    dividecapitalDividend_historyndDueDate: "",
                    companyDividendStatusID: 0,
                    cashDividend: 0,
                    bonusShareDistributed: 0,
                    dividendPercentage: 0,
                    notesEn: "",
                    notesAr: "",
                    createdOn: "",
                    dividendPolicy: "",
                    companyDividendStatusNameEn: "",
                    companyDividendStatusNameAr: "",
                    numberOfShares: 0,
                    cashDividendPerShare: 0,
                    measuringUnitNameAr: "",
                    measuringUnitNameEn: "",
                    currencyNameAr: "",
                    currencyNameEn: "",
                    fundSize: "",
                    sectorID: 0
                }
            ],
            capitalChartData: [{ Capital: 0, FinancialYear: 200 }],
            dividendsChartData: [{ CashDividend: 0, FinancialYear: 200 }],
        },
        Alerts: [
            {
                alertTypeID: 0,
                typeNameEn: "",
                typeNameAr: "",
                isRange: false,
                rangeType: null,
            },
        ],
        AlertSubscriber: {
            email: "",
            firstName: "",
            lastName: "",
            jobTitle: "",
            phoneNo: "",
            countryName: "",
            languageID: this.Language == "ar" ? 1 : 2,
            platform: "Web IR",
            alertTypes: [""],
            updateCode: "",
            showCode: false,
            userMessage: "",
            isError: false,
        },

        MarketData: {
            MarketNameEn: "TASI",
            MarketNameAr: "تاسي",
            StockExchangeNameEn: "",
            StockExchangeNameAr: "",
            TradingDate: "2022-03-01T00:00:00",
            CloseValue: 12674.34,
            PreviousCloseValue: 12590.26,
            OpenValue: 12594.7,
            PercentageChange: 0.6678,
            ChangeValue: 84.08,
            volume: 266790861,
            High: 12748,
            Low: 12583.64,
            DisplayTextAr: "",
            DisplayTextEn: ""
        },

        Countries: [
            { NameEn: "Algeria", NameAr: "الجزائر", Value: "Algeria" },
            { NameEn: "Andorra", NameAr: "أندورا", Value: "Andorra" },
            { NameEn: "Angola", NameAr: "أنغولا", Value: "Angola" },
            { NameEn: "Anguilla", NameAr: "أنغويلا", Value: "Anguilla" },
            { NameEn: "Argentina", NameAr: "الأرجنتين", Value: "Argentina" },
            { NameEn: "Australia", NameAr: "أستراليا", Value: "Australia" },
            { NameEn: "Austria", NameAr: "النمسا", Value: "Austria" },
            { NameEn: "Bahamas", NameAr: "البهاما", Value: "Bahamas" },
            { NameEn: "Bahrain", NameAr: "البحرين", Value: "Bahrain" },
            { NameEn: "Bangladesh", NameAr: "بنغلاديش", Value: "Bangladesh" },
            { NameEn: "Barbados", NameAr: "باربادوس", Value: "Barbados" },
            { NameEn: "Belgium", NameAr: "بلجيكا", Value: "Belgium" },
            { NameEn: "Belize", NameAr: "بليز", Value: "Belize" },
            { NameEn: "Benin", NameAr: "بنين", Value: "Benin" },
            { NameEn: "Bermuda", NameAr: "جزر برمود", Value: "Bermuda" },
            { NameEn: "Bhutan", NameAr: "بوتان", Value: "Bhutan" },
            { NameEn: "Bolivia", NameAr: "بوليفيا", Value: "Bolivia" },
            { NameEn: "Bosina & Herzegovina", NameAr: "البوسنة و الهرسك", Value: "Bosina & Herzegovina" },
            { NameEn: "Botswana", NameAr: "بوتسوانا", Value: "Botswana" },
            { NameEn: "Brazil", NameAr: "البرازيل", Value: "Brazil" },
            { NameEn: "Bulgaria", NameAr: "بلغاريا", Value: "Bulgaria" },
            { NameEn: "Burma", NameAr: "ميانمار", Value: "Burma" },
            { NameEn: "Canada", NameAr: "كندا", Value: "Canada" },
            { NameEn: "Chile", NameAr: "تشيلي", Value: "Chile" },
            { NameEn: "China", NameAr: "الصين", Value: "China" },
            { NameEn: "Costa Rica", NameAr: "كوستاريكا", Value: "Costa Rica" },
            { NameEn: "Cuba", NameAr: "كوبا", Value: "Cuba" },
            { NameEn: "Cyprus", NameAr: "قبرص", Value: "Cyprus" },
            { NameEn: "Czech", NameAr: "التشيك", Value: "Czech" },
            { NameEn: "Denmark", NameAr: "الدنمارك", Value: "Denmark" },
            { NameEn: "Ecuador", NameAr: "الإكوادور", Value: "Ecuador" },
            { NameEn: "Egypt", NameAr: "مصر", Value: "Egypt" },
            { NameEn: "Eritrea", NameAr: "إريتريا", Value: "Eritrea" },
            { NameEn: "Ethiopia", NameAr: "إثيوبيا", Value: "Ethiopia" },
            { NameEn: "Falkland Islands", NameAr: "جزر فوكلاند", Value: "Falkland Islands" },
            { NameEn: "Faroe Island", NameAr: "جزر فارو", Value: "Faroe Island" },
            { NameEn: "Fiji", NameAr: "فيجي", Value: "Fiji" },
            { NameEn: "Finland", NameAr: "فنلندا", Value: "Finland" },
            { NameEn: "France", NameAr: "فرنسا", Value: "France" },
            { NameEn: "French Guyana", NameAr: "غويانا الفرنسية", Value: "French Guyana" },
            { NameEn: "French Polynesia", NameAr: "بولينيزيا الفرنسية", Value: "French Polynesia" },
            { NameEn: "Gabon", NameAr: "الغابون", Value: "Gabon" },
            { NameEn: "Gambia", NameAr: "غامبيا", Value: "Gambia" },
            { NameEn: "Georgia", NameAr: "جيورجيا", Value: "Georgia" },
            { NameEn: "Germany", NameAr: "ألمانيا", Value: "Germany" },
            { NameEn: "Ghana", NameAr: "غانا", Value: "Ghana" },
            { NameEn: "Gibralter", NameAr: "جبل طارق", Value: "Gibralter" },
            { NameEn: "Greece", NameAr: "اليونان", Value: "Greece" },
            { NameEn: "Greenland", NameAr: "جرينلاند", Value: "Greenland" },
            { NameEn: "Guadeloupe", NameAr: "جزر جوادلوب", Value: "Guadeloupe" },
            { NameEn: "Guam", NameAr: "جوام", Value: "Guam" },
            { NameEn: "Guatemala", NameAr: "غواتيمال", Value: "Guatemala" },
            { NameEn: "Guinea", NameAr: "غينيا", Value: "Guinea" },
            { NameEn: "Guyana Rep.", NameAr: "غيانا", Value: "Guyana Rep." },
            { NameEn: "Haiti Rep.", NameAr: "هايتي", Value: "Haiti Rep." },
            { NameEn: "Honduras Rep.", NameAr: "هندوراس", Value: "Honduras Rep." },
            { NameEn: "Hong Kong", NameAr: "هونغ كونغ", Value: "Hong Kong" },
            { NameEn: "Hungary", NameAr: "المجر", Value: "Hungary" },
            { NameEn: "Iceland", NameAr: "آيسلندا", Value: "Iceland" },
            { NameEn: "India", NameAr: "الهند", Value: "India" },
            { NameEn: "Indonesia", NameAr: "إندونيسيا", Value: "Indonesia" },
            { NameEn: "Iran", NameAr: "ايران", Value: "Iran" },
            { NameEn: "Iraq", NameAr: "العراق", Value: "Iraq" },
            { NameEn: "Ireland", NameAr: "أيرلندا", Value: "Ireland" },
            { NameEn: "Isreal", NameAr: "إسرائيل", Value: "Isreal" },
            { NameEn: "Italy", NameAr: "إيطاليا", Value: "Italy" },
            { NameEn: "Ivory Coast", NameAr: "ساحل العاج", Value: "Ivory Coast" },
            { NameEn: "Jamaica", NameAr: "جمايكا", Value: "Jamaica" },
            { NameEn: "Japan", NameAr: "اليابان", Value: "Japan" },
            { NameEn: "Jordan", NameAr: "الاردن", Value: "Jordan" },
            { NameEn: "Kenya", NameAr: "كينيا", Value: "Kenya" },
            { NameEn: "Kiribati", NameAr: "كيريباتي", Value: "Kiribati" },
            { NameEn: "North Korea", NameAr: "كوريا الشمالية", Value: "North Korea" },
            { NameEn: "Kuwait", NameAr: "الكويت", Value: "Kuwait" },
            { NameEn: "Latvia", NameAr: "لاتفيا", Value: "Latvia" },
            { NameEn: "Lebanon", NameAr: "لبنان", Value: "Lebanon" },
            { NameEn: "Liberia Rep.", NameAr: "ليبيريا", Value: "Liberia Rep." },
            { NameEn: "Libya", NameAr: "ليبيا", Value: "Libya" },
            { NameEn: "Liechtenstein", NameAr: "ليختنشتين", Value: "Liechtenstein" },
            { NameEn: "Lithuania", NameAr: "لتوانيا", Value: "Lithuania" },
            { NameEn: "Luxembourg", NameAr: "لوكسمبورغ", Value: "Luxembourg" },
            { NameEn: "Macao", NameAr: "ماكاو", Value: "Macao" },
            { NameEn: "Madagascar", NameAr: "مدغشقر", Value: "Madagascar" },
            { NameEn: "Malawi", NameAr: "مالاوي", Value: "Malawi" },
            { NameEn: "Malaysia", NameAr: "ماليزيا", Value: "Malaysia" },
            { NameEn: "Maldives", NameAr: "جزر المالديف", Value: "Maldives" },
            { NameEn: "Mali Rep.", NameAr: "مالي", Value: "Mali Rep." },
            { NameEn: "Malta", NameAr: "مالطا", Value: "Malta" },
            { NameEn: "Mauritius", NameAr: "موريشيوس", Value: "Mauritius" },
            { NameEn: "Mayotee", NameAr: "مايوت", Value: "Mayotee" },
            { NameEn: "Mexico", NameAr: "المكسيك", Value: "Mexico" },
            { NameEn: "Mongolia Rep.", NameAr: "منغوليا", Value: "Mongolia Rep." },
            { NameEn: "Morocco", NameAr: "المغرب", Value: "Morocco" },
            { NameEn: "Mozambique", NameAr: "موزمبيق", Value: "Mozambique" },
            { NameEn: "Myanmar", NameAr: "بورما", Value: "Myanmar" },
            { NameEn: "Namibia", NameAr: "ناميبيا", Value: "Namibia" },
            { NameEn: "Nauru Rep.", NameAr: "ناورو", Value: "Nauru Rep." },
            { NameEn: "Nepal", NameAr: "نيبال", Value: "Nepal" },
            { NameEn: "Netherlands", NameAr: "هولندا", Value: "Netherlands" },
            { NameEn: "New Zealand", NameAr: "نيوزيلندا", Value: "New Zealand" },
            { NameEn: "Nicaragua", NameAr: "نيكاراجوا", Value: "Nicaragua" },
            { NameEn: "Niger Rep.", NameAr: "النيجر", Value: "Niger Rep." },
            { NameEn: "Nigeria Rep.", NameAr: "نيجيريا", Value: "Nigeria Rep." },
            { NameEn: "Norfolk Island", NameAr: "جزيرة نورفولك", Value: "Norfolk Island" },
            { NameEn: "Norway", NameAr: "النرويج", Value: "Norway" },
            { NameEn: "Oman", NameAr: "سلطنة عمان", Value: "Oman" },
            { NameEn: "Pakistan", NameAr: "باكستان", Value: "Pakistan" },
            { NameEn: "Palau", NameAr: "بالاو", Value: "Palau" },
            { NameEn: "Panama", NameAr: "بنما", Value: "Panama" },
            { NameEn: "Paraguay", NameAr: "باراغواي", Value: "Paraguay" },
            { NameEn: "Peru", NameAr: "بيرو", Value: "Peru" },
            { NameEn: "Phillipines", NameAr: "الفلبين", Value: "Phillipines" },
            { NameEn: "Poland", NameAr: "بولندا", Value: "Poland" },
            { NameEn: "Portugal", NameAr: "البرتغال", Value: "Portugal" },
            { NameEn: "Qatar", NameAr: "قطر", Value: "Qatar" },
            { NameEn: "Romania", NameAr: "رومانيا", Value: "Romania" },
            { NameEn: "Russia", NameAr: "روسيا", Value: "Russia" },
            { NameEn: "Rwanda Rep.", NameAr: "رواندا", Value: "Rwanda Rep." },
            { NameEn: "Saudi Arabia", NameAr: "المملكة العربية السعودية", Value: "Saudi Arabia" },
            { NameEn: "Senegal", NameAr: "السنغال", Value: "Senegal" },
            { NameEn: "Seychelles", NameAr: "سيشيل", Value: "Seychelles" },
            { NameEn: "Singapore", NameAr: "سنغافورة", Value: "Singapore" },
            { NameEn: "Slovak Rep.", NameAr: "سلوفاكيا", Value: "Slovak Rep." },
            { NameEn: "Slovinia", NameAr: "سلوفينيا", Value: "Slovinia" },
            { NameEn: "Solomon Island", NameAr: "جزر سليمان", Value: "Solomon Island" },
            { NameEn: "Somalia", NameAr: "الصومال", Value: "Somalia" },
            { NameEn: "South Africa", NameAr: "جنوب أفريقيا", Value: "South Africa" },
            { NameEn: "South Korea", NameAr: "كوريا الجنوبية", Value: "South Korea" },
            { NameEn: "Spain", NameAr: "إسبانيا", Value: "Spain" },
            { NameEn: "Sri Lanka", NameAr: "سيريلانكا", Value: "Sri Lanka" },
            { NameEn: "Sudan", NameAr: "السودان", Value: "Sudan" },
            { NameEn: "Sweden", NameAr: "السويد", Value: "Sweden" },
            { NameEn: "Switzerland", NameAr: "سويسرا", Value: "Switzerland" },
            { NameEn: "Syria", NameAr: "سوريا", Value: "Syria" },
            { NameEn: "Taiwan", NameAr: "تايوان", Value: "Taiwan" },
            { NameEn: "Tanzania", NameAr: "تونس", Value: "Tanzania" },
            { NameEn: "Thailand", NameAr: "تايلندا", Value: "Thailand" },
            { NameEn: "Turkey", NameAr: "تركيا", Value: "Turkey" },
            { NameEn: "UAE", NameAr: "الإمارات", Value: "UAE" },
            { NameEn: "Uganda", NameAr: "أوغندا", Value: "Uganda" },
            { NameEn: "Ukraine", NameAr: "أوكرانيا", Value: "Ukraine" },
            { NameEn: "Uruguay", NameAr: "أورغواي", Value: "Uruguay" },
            { NameEn: "USA", NameAr: "الولايات المتحدة الامريكية", Value: "USA" },
            { NameEn: "Uzbekistan", NameAr: "أوزباكستان", Value: "Uzbekistan" },
            { NameEn: "Vatican City", NameAr: "دولة مدينة الفاتيكان", Value: "Vatican City" },
            { NameEn: "Venezuela", NameAr: "فنزويلا", Value: "Venezuela" },
            { NameEn: "Vietnam", NameAr: "فيتنام", Value: "Vietnam" },
            { NameEn: "Yeman (PDR)", NameAr: "جنوب اليمن", Value: "Yeman (PDR)" },
            { NameEn: "Yeman Arab Republic", NameAr: "اليمن", Value: "Yeman Arab Republic" },
            { NameEn: "Zambia", NameAr: "زامبيا", Value: "Zambia" },
            { NameEn: "Zimbabwe", NameAr: "زمبابوي", Value: "Zimbabwe" },
            { NameEn: "Palestine", NameAr: "فلسطين", Value: "Palestine" },
            { NameEn: "south korea", NameAr: "كوريا الجنوبية", Value: "south korea" },
            { NameEn: "Cayman Islands", NameAr: "جزر الكايمن", Value: "Cayman Islands" },
            { NameEn: "United Kingdom", NameAr: "المملكة المتحدة", Value: "United Kingdom" },
            { NameEn: "Kazakhstan", NameAr: "كازاخستان", Value: "Kazakhstan" },
            { NameEn: "Turkmenistan", NameAr: "تركمنستان", Value: "Turkmenistan" },
            { NameEn: "Tunisia", NameAr: "تونس", Value: "Tunisia" },
            { NameEn: "Papua New Guinea", NameAr: "بابوا غينيا الجديدة", Value: "Papua New Guinea" },
            { NameEn: "Marshall Islands", NameAr: "جزر المارشال", Value: "Marshall Islands" },
            { NameEn: "Jersey", NameAr: "جيرسي", Value: "Jersey" },
        ],
        MonthNames: [
            "يناير",
            "فبراير",
            "مارس",
            "أبريل ",
            "مايو",
            "يونيو ",
            "يوليو ",
            "أغسطس",
            "سبتمبر",
            "أكتوبر",
            "نوفمبر",
            "ديسمبر",
        ],
        MonthNameEn: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "May",
            "June",
            "July",
            "Aug",
            "Sept",
            "Oct",
            "Nov",
            "Dec",
        ],
        MonthFullNameEn: [
            "January",
            "February",
            "March",
            "April",
            "May",
            "June",
            "July",
            "August",
            "September",
            "October",
            "November",
            "December",
        ],
        SelectedEvent:
        {
            calendarEventID: 0,
            calendarEventTypeID: 0,
            companyID: 0,
            companyNameAr: "",
            companyNameEn: "",
            descriptionAr: "",
            descriptionEn: "",
            eventLocationAr: "",
            eventLocationEn: "",
            latitude: null,
            longitude: null,
            marketID: 3,
            marketNameAr: "",
            marketNameEn: "",
            occursOn: "",
            titleAr: "",
            titleEn: "",
            typeNameAr: "",
            typeNameEn: "",
            articleLinkURLAr: "",
            articleLinkURLEn: "",
        },
        disclosureTimeout: ''
    },
    mounted: function () {
        var app = this;
        app.PageLoading = false;

        this.getAccessToken()
            .then(
                function (response) {
                    app._token = response;

                    var hash = window.location.hash;

                    if (hash.startsWith("#p_")) {
                        app.fetchCompanyOverView(response);

                        var pn = hash.replace('#p_', '');

                        $("[data-cont='." + pn + "']").click();
                    }
                    else if (hash.startsWith("#n_")) {
                        app.fetchCompanyOverView(response);

                        app.LoadPage('disclosures', app.loadDisclosures, false);

                        var pn = hash.replace('#n_', '');

                        var section = pn.split('|')[0];
                        var articleID = pn.split('|')[1];

                        app.openNews(section, articleID, undefined, 'DontLoadPage');
                    }
                    else {
                        app.LoadPage('overview', app.loadCompanyOverView);
                    }
                },
                function () {
                    app.Loading.Prices = true;
                    app.Loading.ProfileInfo = true;

                    alert("rejected !!");
                }
            )
            .catch(function (ex) {
                alert(ex);
            });
    },
    methods: {
        getAccessToken: function () {
            var app = this;

            if (this.accessTokenExpireIn < new Date()) {
                var authUrl = baseUrl + "/authenticate";
                var data = { username: api_user, password: api_password };

                return axios
                    .post(authUrl, data)
                    .then(function (response) {
                        var data_1 = response.data;
                        app._token = data_1.jwtToken;
                        app.accessTokenExpireIn = data_1.expires;
                        return Promise.resolve(response.data.jwtToken);
                    })
                    .catch(function (exception) {
                        console.log("Error:" + exception);
                        throw exception;
                        return Promise.reject(exception);
                    });
            } else {
                return Promise.resolve(this._token);
            }
        },
        getFetch: function (url) {
            const apiUrl = `${baseUrl}/api/v${api_version}/json/${url}`;

            return this.getAccessToken().then(function (act) {
                return axios({
                    url: apiUrl,
                    method: "GET",
                    headers: {
                        "Content-Type": "application/json",
                        authorization: "Bearer " + act,
                    },
                }).then((res) => res);
            });
        },
        postFetch: function (url, data) {
            const apiUrl = `${baseUrl}/api/v${api_version}/json/${url}`;

            return this.getAccessToken().then(function (act) {
                var headers = {
                    "Content-Type": "application/json",
                    authorization: "Bearer " + act,
                };

                return axios.post(apiUrl, data, { headers }).then(res => res);
            });
        },
        LoadPage: function (pageName, loadFunc, changeHash) {
            this.Loading.Page = true;

            $(".widget-page").fadeOut(800);
            $(".js-preloader").show();

            loadFunc(function () {
                $(".widget-page." + pageName).fadeIn({
                    duration: 0,
                    start: function () {
                        $(".js-preloader").hide();
                        $('body,html').animate({
                            scrollTop: $('.overlay-container').offset().top + 1
                        }, 250);
                    }
                });
            });

            this.Loading.Page = false;

            $(".tabs li.active").removeClass("active");
            $("[data-cont='." + pageName + "']").addClass("active");

            this.PageLoading = true;

            if (changeHash != false) {
                window.location.hash = 'p_' + pageName;
            }
        },
        LoadMobilePage: function (pageName, loadFunc, pageTitle, changeHash) {
            $(".overlay-container").removeClass("show");
            $(".mobile-dropdown span").html(pageTitle);

            this.LoadPage(pageName, loadFunc, changeHash);
        },
        openNews: function (section, id, article, dontLoadPage) {
            var app = this;
            app.PageLoading = true;

            if (dontLoadPage === undefined) {
                app.LoadPage('disclosures', this.loadDisclosures);
            }

            clearTimeout(app.disclosureTimeout);
            app.disclosureTimeout = setTimeout(() => {
                app.openDisclosures(section);
            }, 200);

            var hash = "n_" + section;
            if(id != undefined && id != '')
            {
                hash = hash + '|' + id;

                $('.disclosurePopup').hide();
                app.showNewsPopup(section, id);  
            }

            window.location.hash = hash;

            if (article !== undefined) {
                if (article.body == null) {
                    article.body = '<span> Loading.....</span>';
                    app.fetchArticleBody(article);
                }
            }
        },
        closeNews: function (section, id) {
            $('.disclosurePopup').hide();
        },
        showNewsPopup: function (section, id) {
            var app = this;
            if ($('#' + section + '_id_' + id).length > 0) {
                setTimeout(() => {
                    console.log($('#' + section + '_id_' + id));

                    $('#' + section + '_id_' + id).show();
                }, 500);
            }
            else {
                setTimeout(() => {
                    app.showNewsPopup(section, id);
                }, 1000);
            }
        },
        openAnalystEstimates: function () {
            this.LoadPage('analyst-coverage', this.loadCompanyAnalystCoverage);
        },
        loadCompanyOverView: function (callBack) {
            var app = this;

            this.getAccessToken().then(function (response) {
                app.fetchCompanyOverView(response);
                app.fetchMarketData(response);
                app.fetchCompanyAnalystOpinions(response);

                app.fetchCartData('overviewchart', '1D');

                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyOverView: function (accT) {
            this.Loading.CompanyOverview = true;

            var app = this;

            this.getFetch("ir-api/overview/" + app.Language).then(resp => {
                app.CompanyOverview = resp.data;
                app.Loading.CompanyOverview = false;

                app.fetchCompanyProfile(function () { });

                app.MarketValue = app.CompanyProfile.tradingData.numberOfShares * app.CompanyOverview.prices[0].closeValue;

            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyProfile: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyProfile(response);

                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyProfile: function (accT) {
            this.Loading.CompanyProfile = true;

            var app = this;

            this.getFetch("ir-api/profile/").then(resp => {
                app.CompanyProfile = resp.data;
                app.MarketValue = app.CompanyProfile.tradingData.numberOfShares * app.CompanyOverview.prices[0].closeValue;
                app.Loading.CompanyProfile = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchMarketData: function (accT) {
            var app = this;
            this.getFetch("ir-api/market-data/").then(resp => {
                app.MarketData = resp.data.ticker;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyChart: function (callBack) {
            var app = this;
            $('#calender--chart').daterangepicker({
                opens: 'left'
            }, function (start, to, label) {
                $("#chartDataFromDate").val(start.format('YYYY-MM-DD'));
                $("#chartDataToDate").val(to.format('YYYY-MM-DD'));

                $("#calender--chart").val(start.format('DD-MM-YYYY') + " - " + to.format('DD-MM-YYYY'));

                $("#chartExcelLink").attr("href", "https://www.argaam.com/en/company-chart/marketid/3?companyID=85&fromDate=" + start.format('MM/DD/YYYY') + "&toDate=" + to.format('MM/DD/YYYY'));
            });

            var start = moment().subtract(7, 'days');
            var to = moment();

            $("#chartDataFromDate").val(start.format('YYYY-MM-DD'));
            $("#chartDataToDate").val(to.format('YYYY-MM-DD'));
            $("#calender--chart").val(start.format('DD-MM-YYYY') + " - " + to.format('DD-MM-YYYY'));

            $("#chartExcelLink").attr("href", "https://www.argaam.com/en/company-chart/marketid/3?companyID=85&fromDate=" + start.format('MM/DD/YYYY') + "&toDate=" + to.format('MM/DD/YYYY'));

            this.getAccessToken().then(function (response) {
                app.fetchCompanyChart(response);
                app.fetchMainChart();
                //app.fetchCartData('mainChart', 'AY');
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyChart: function (accT) {
            this.Loading.CompanyChart = true;
            console.log("Loading Data for :" + $("#calender--chart").val());
            var from = $("#chartDataFromDate").val();
            var to = $("#chartDataToDate").val();

            var app = this;
            this.getFetch("ir-api/chart-data-table/" + from + "/" + to).then(resp => {
                app.CompanyChart = resp.data;
                app.Loading.CompanyChart = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchMainChart: function (chartType = 'line') {
            var apiUrl = baseUrl + "/api/v" + api_version + "/json/ir-api/charts-data/0/5Y";
            var app = this;
            app.getAccessToken().then(function (act) {
                axios.get(apiUrl, { headers: { 'Content-Type': 'application/json', 'authorization': 'Bearer ' + app._token } })
                    .then(function (response) {
                        app.chartData = response.data.data;
                        var data = app.chartData;
                        var ohlc = [],
                            volume = [],
                            dataLength = data.length,
                            i = 1;

                        for (i; i < dataLength; i += 1) {
                            ohlc.push([
                                new Date(String(data[i]['date'].replace(' ', 'T'))).getTime(), // the date
                                data[i]['open'], // open
                                data[i]['high'], // high
                                data[i]['low'], // low
                                data[i]['close'] // close
                            ]);

                            volume.push([
                                new Date(String(data[i]['date'].replace(' ', 'T'))).getTime(), // the date
                                data[i]['volume'] // the volume
                            ]);
                        }
                        Highcharts.stockChart('mainChart', {
                            chart: {
                                backgroundColor: 'transparent',
                                color: '#fff'
                            },
                            xAxis: {
                                gridLineColor: '#63C5B7',
                                labels: {
                                    style: {
                                        color: '#63C5B7'
                                    }
                                },
                                lineColor: '#63C5B7',
                                minorGridLineColor: '#63C5B7',
                                tickColor: '#63C5B7',
                                title: {
                                    style: {
                                        color: '#63C5B7'
                                    }
                                }
                            },
                            exporting: {
                                enabled: false
                            },
                            yAxis: [{
                                gridLineColor: '#63C5B7',
                                labels: {
                                    align: 'left',
                                    style: {
                                        color: '#63C5B7'
                                    }
                                },
                                height: '80%',
                                resize: {
                                    enabled: true
                                }
                            }, {
                                labels: {
                                    align: 'left',
                                    style: {
                                        color: '#63C5B7'
                                    }
                                },
                                top: '80%',
                                height: '20%',
                                offset: 0,

                            }],
                            tooltip: {
                                shape: 'square',
                                headerShape: 'callout',
                                borderWidth: 0,
                                valueDecimals: 2,
                                shadow: false,
                                positioner: function (width, height, point) {
                                    var chart = this.chart,
                                        position;

                                    if (point.isHeader) {
                                        position = {
                                            x: Math.max(
                                                // Left side limit
                                                chart.plotLeft,
                                                Math.min(
                                                    point.plotX + chart.plotLeft - width / 2,
                                                    // Right side limit
                                                    chart.chartWidth - width - chart.marginRight
                                                )
                                            ),
                                            y: point.plotY
                                        };
                                    } else {
                                        position = {
                                            x: point.series.chart.plotLeft,
                                            y: point.series.yAxis.top - chart.plotTop
                                        };
                                    }

                                    return position;
                                }
                            },
                            series: [{
                                type: chartType,
                                threshold: null,
                                id: 'savola-tasi',
                                name: 'Savola Group',
                                color: '#63C5B7',
                                data: ohlc
                            }, {
                                type: 'column',
                                id: 'savola-volume',
                                name: 'Savola Volume',
                                data: volume,
                                color: '#63C5B7',
                                yAxis: 1
                            }],
                            responsive: {
                                rules: [{
                                    condition: {
                                        maxWidth: 800
                                    },
                                    chartOptions: {
                                        rangeSelector: {
                                            inputEnabled: false
                                        }
                                    }
                                }]
                            }
                        });

                    })
                    .catch(function (exception) {
                        console.log('Error:' + exception);
                    });
            });
        },
        fetchCartData: function (chartDiv, period, chartType = 'line') {
            $('.ticker-tab [data-cont]').removeClass('active');
            $('.ticker-tab [data-cont="' + period + '"]').addClass('active');
            var apiUrl = baseUrl + "/api/v" + api_version + "/json/ir-api/charts-data/0/" + period;
            var app = this;
            axios.get(apiUrl, { headers: { 'Content-Type': 'application/json', 'authorization': 'Bearer ' + app._token } })
                .then(function (response) {
                    app.chartData = response.data.data;
                    var data = app.chartData;
                    Highcharts.stockChart(chartDiv, {
                        chart: {
                            renderTo: chartDiv,
                            backgroundColor: 'transparent'
                        },
                        rangeSelector: {
                            enabled: false
                        },
                        plotOptions: {
                            series: {
                                lineWidth: 4
                            }
                        },
                        responsive: {
                            rules: [{
                                condition: {
                                    maxWidth: 500
                                },
                                chartOptions: {
                                    legend: {
                                        enabled: false
                                    }
                                }
                            }]
                        },
                        series: [{
                            name: 'Savola Group',
                            // type: 'area',
                            type: chartType,
                            data: data,
                            color: '#63C5B7',
                            tooltip: {
                                valueDecimals: 2
                            },
                            turboThreshold: 1000000
                        }],
                        exporting: {
                            enabled: false
                        },
                        yAxis: [{
                            id: "main-series",
                            startOfWeek: 0,
                            labels: {
                                formatter: function () {
                                    return Highcharts.numberFormat(this.value, 2);
                                },
                                offset: 0,
                                lineWidth: 1,
                                style: {
                                    color: '#63C5B7'
                                }
                            }
                        }],
                        xAxis: [{
                            id: "main-series",
                            labels: {
                                style: {
                                    color: '#63C5B7'
                                }
                            }
                        }],
                        tooltip: {
                            formatter: function () {
                                return Highcharts.dateFormat(period.includes('D') ? '%B %e, %Y %H:%M' : '%B %e, %Y', this.x) + '<br/><b>Savola Group </b>:' +
                                    Highcharts.numberFormat(this.y, 2);
                            }
                        },
                        annotationsOptions: { enabledButtons: false },
                        navigator: { enabled: false },
                        scrollbar: { enabled: false }
                    });
                })
                .catch(function (exception) {
                    console.log('Error:' + exception);
                });
        },
        loadCompanyInvestorPresentation: function (callBack) {
            var app = this;

            $("#investorPresentationFromDate").val("");
            $("#investorPresentationToDate").val("");
            $("#calender--investor").val("");

            this.getAccessToken().then(function (response) {
                app.fetchCompanyInvestorPresentation(response, '1');
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyInvestorPresentation: function (accT, reportTypeID) {
            this.Loading.CompanyInvestorPresentations = true;
            var app = this;

            var from = $("#investorPresentationFromDate").val();
            var to = $("#investorPresentationToDate").val();

            reportTypeID = reportTypeID == undefined ? '' : reportTypeID;

            this.getFetch("ir-api/investors-presentation?reportTypeID=" + reportTypeID + "&dateFrom=" + from + "&dateTo=" + to).then(resp => {
                app.CompanyInvestorPresentations = resp.data;
                app.Loading.CompanyInvestorPresentations = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        searchCompanyInvestorPresentation: function () {
            this.fetchCompanyInvestorPresentation("", this.CompanyInvestorPresentations.reportTypeID);
        },
        loadCompanySegments: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyBusinessSegments("year", "riyal");
                app.fetchCompanyGeolocationSegments("year", "riyal");
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        changeCompanyBusinessSegmentsCurrency: function (currency) {
            $(".main-financial-statement__title__options__tabs li").removeClass("active");
            this.fetchCompanyBusinessSegments(this.CompanyBusinessSegments.fiscalPeriodType, currency);
            $(".main-financial-statement__title__options__tabs__" + currency).addClass("active");
        },
        changeCompanyBusinessSegmentsFiscalPeriodType: function (fiscalPeriodType) {
            $("li", ".main-business-segment-fs__tabs").removeClass("active");
            this.fetchCompanyBusinessSegments(fiscalPeriodType, this.CompanyBusinessSegments.currency);
            $("." + fiscalPeriodType + "-tab", ".main-business-segment-fs__tabs").addClass("active");
        },
        changeCompanyGeolocationSegmentsCurrency: function (currency) {
            $(".main-geolocationSegment__title__options__tabs li").removeClass("active");
            this.fetchCompanyGeolocationSegments(this.CompanyGeolocationSegments.fiscalPeriodType, currency);
            $(".main-geolocationSegment__title__options__tabs__" + currency).addClass("active");
        },
        changeCompanyGeolocationSegmentsFiscalPeriodType: function (fiscalPeriodType) {
            $("li", ".main-geolocation-segment-fs__tabs").removeClass("active");
            this.fetchCompanyGeolocationSegments(fiscalPeriodType, this.CompanyGeolocationSegments.currency);
            $("." + fiscalPeriodType + "-tab", ".main-geolocation-segment-fs__tabs").addClass("active");
        },
        fetchCompanyBusinessSegments: function (fiscalPeriodType, currency) {
            this.Loading.CompanyBusinessSegments = true;
            var app = this;
            this.getFetch("ir-api/business-segments?fiscalPeriodType=" + fiscalPeriodType + "&currency=" + currency).then(resp => {
                app.CompanyBusinessSegments = resp.data;
                app.Loading.CompanyBusinessSegments = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchCompanyGeolocationSegments: function (fiscalPeriodType, currency) {
            this.Loading.CompanyGeolocationSegments = true;
            var app = this;
            this.getFetch("ir-api/geolocation-segments?fiscalPeriodType=" + fiscalPeriodType + "&currency=" + currency).then(resp => {
                app.CompanyGeolocationSegments = resp.data;
                app.Loading.CompanyGeolocationSegments = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyAnalystCoverage: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyAnalystOpinions(response);
                app.fetchCompanyAnalystEstimates(response, 'year');
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyAnalystOpinions: function (accT) {
            this.Loading.CompanyAnalystOpinions = true;
            var app = this;
            this.getFetch("company/get-analyst-opinions/" + app.marketId + "/" + app.companyId).then(resp => {
                app.CompanyAnalystOpinions = resp.data;
                app.Loading.CompanyAnalystOpinions = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchCompanyAnalystEstimates: function (accT, fiscalPeriodType) {
            this.Loading.CompanyAnalystEstimates = true;
            var app = this;
            this.getFetch("company/get-analyst-estimates/" + app.marketId + "/" + app.companyId + "?fiscalPeriodType=" + fiscalPeriodType).then(resp => {
                app.CompanyAnalystEstimates = resp.data;
                app.Loading.CompanyAnalystEstimates = false;
                app.setCurrencyAnalystEstimates('Riyal');
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyMergerAcquisitions: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyMergerAcquisitions(response);
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyMergerAcquisitions: function (accT) {
            this.Loading.CompanyMergerAcquisitions = true;
            var app = this;
            this.getFetch("company/get-mergers-acquisitions/" + app.marketId + "/" + app.companyId).then(resp => {
                app.CompanyMergerAcquisitions = resp.data;
                app.Loading.CompanyMergerAcquisitions = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyFStatements: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyFStatements(response);
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyFStatements: function (accT) {
            this.Loading.CompanyFStatements = true;
            var app = this;
            this.getFetch("ir-api/financial-statements/" + app.Language).then(resp => {
                app.CompanyFStatements = resp.data;
                app.Loading.CompanyFStatements = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchCompanyFStatementsForPeriod: function (fiscalPeriodType) {
            this.Loading.CompanyFStatements = true;
            var app = this;
            this.getFetch("ir-api/financial-statements/" + app.Language + "?fiscalPeriodType=" + fiscalPeriodType).then(resp => {
                app.CompanyFStatements = resp.data;
                app.setCurrencyFinancialStatement('riyal')
                app.Loading.CompanyFStatements = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadFinancialReports: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchFinancialReports(response);
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchFinancialReports: function (accT) {
            this.Loading.FinancialReports = true;
            var app = this;
            this.getFetch("ir-api/financial-results/" + app.Language).then(resp => {
                app.FinancialResults = resp.data;
                app.Loading.FinancialReports = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        loadCompanyFRatios: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCompanyFRatios(response);
                callBack();
            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCompanyFRatios: function (accT) {
            this.Loading.CompanyFRatios = true;
            var app = this;
            this.getFetch("ir-api/financial-ratios").then(resp => {
                app.CompanyFRatios = resp.data;
                app.setCurrencyFinancialRatios('Riyal');
                app.Loading.CompanyFRatios = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        fetchCompanyFRatiosForPeriod: function (fiscalPeriodType) {
            this.Loading.CompanyFRatios = true;
            var app = this;
            this.getFetch("ir-api/financial-ratios?fiscalPeriodType=" + fiscalPeriodType).then(resp => {
                app.CompanyFRatios = resp.data;
                app.setCurrencyFinancialRatios('Riyal');
                app.Loading.CompanyFRatios = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        showChartForFinancialHighlight: function (fn) {
            var app = this;
            $(".Financials-Highlights__popup").show();
            var data = [];
            var cat = [];
            app.getFinancialHighlightYears().forEach(function (y) {
                cat.push(y);
                data.push(fn[y]);
            });
            var title = app.Language == "en" ? fn.DisplayNameEn : fn.DisplayNameAr;
            app.populateChart(data, cat, 'financialhighligh_chart', title);
        },
        hideChartForFinancialHighlight: function (fn) {
            $(".Financials-Highlights__popup").hide();
        },
        showChartForBusinessSegment: function (fsfield) {
            var app = this;
            $(".bs-popup").show();
            var data = [];
            var cat = [];
            fsfield.periodicValues.slice(0, 5).forEach(function (v) {
                data.push(v.value);
                cat.push(v.forDate);
            });
            var title = app.Language == "en" ? fsfield.businessSegmentNameEn : fsfield.businessSegmentNameAr;

            app.populateChart(data, cat, 'bs_details_chart', title);
        },
        hideChartForBusinessSegment: function () {
            $(".bs-popup").hide();
        },
        showChartForAnalystEstimate: function (fsfield) {
            var app = this;
            $(".aes-popup").show();
            var data = [];
            var cat = [];
            fsfield.periodValues.slice(0, 5).forEach(function (v) {
                data.push(v.estimatedValue);
                cat.push("(e) " + v.forYear);

                data.push(v.actualValue);
                cat.push("(a) " + v.forYear);
            });
            var title = app.Language == "en" ? fsfield.fsFieldNameEn : fsfield.fsFieldNameAr;

            app.populateChart(data, cat, 'bs_aes_details_chart', title);
        },
        hideChartForAnalystEstimate: function () {
            $(".aes-popup").hide();
        },
        showChartForGeolocationSegment: function (fsfield) {
            var app = this;
            $(".gs-popup").show();
            var data = [];
            var cat = [];
            fsfield.periodicValues.slice(0, 5).forEach(function (v) {
                data.push(v.value);
                cat.push(v.forDate);
            });
            var title = app.Language == "en" ? fsfield.businessSegmentNameEn : fsfield.businessSegmentNameAr;

            app.populateChart(data, cat, 'gs_details_chart', title);
        },
        hideChartForGeolocationSegment: function () {
            $(".gs-popup").hide();
        },
        showChartForFinancialStatement: function (fsfield) {
            var app = this;
            $(".fn-popup").show();
            var data = [];
            var cat = [];
            fsfield.values.slice(0, 5).forEach(function (v) {
                data.push(v.value);
                cat.push(v.fiscalPeriod);
            });
            var title = app.Language == "en" ? fsfield.displayNameEn : fsfield.displayNameAr;

            app.populateChart(data, cat, 'fs_details_chart', title);
        },
        hideChartForFinancialStatement: function () {
            $(".fn-popup").hide();
        },
        showChartForFinancialRatio: function (fsRatio) {
            var app = this;
            $(".fr-popup").show();
            var data = [];
            var cat = [];
            fsRatio.values.slice(0, 5).forEach(function (v) {
                if (v.value !== '-') {
                    data.push(parseFloat(v.value));
                } else {
                    data.push(0);
                }
                var p = v.period == "-" ? v.year : v.period;
                cat.push(p);
            });
            var title = app.Language == "en" ? fsRatio.nameEn : fsRatio.nameAr;

            app.populateChart(data, cat, 'fr_details_chart', title);
        },
        hideChartForFinancialRatio: function () {
            $(".fr-popup").hide();
        },
        loadCorporateActions: function (callBack) {
            var app = this;
            this.getAccessToken().then(function (response) {
                app.fetchCorporateActions(response);
                callBack();

            }, function () {
                app.Loading.Page = false;
                alert("Unable to connect to Argaam!!!");
            }).catch(function (ex) {
                alert(ex);
            });
        },
        fetchCorporateActions: function (accT) {
            this.Loading.CorporateActions = true;
            var app = this;
            this.getFetch("ir-api/corporate-actions/" + app.Language).then(resp => {
                app.CorporateActions = resp.data;
                var capitalData = [];
                var cpaitalCategories = [];

                app.CorporateActions.capitalChartData.reverse().slice(0, 6).forEach(function (v) {
                    capitalData.push(v.Capital);
                    cpaitalCategories.push(v.FinancialYear);
                });

                app.populateChart(capitalData, cpaitalCategories, 'capital_change_chart', "", 80);

                var dividendData = [];
                var devidendCategories = [];

                app.CorporateActions.dividendPerShareChartData.forEach(function (v) {
                    dividendData.push(v.CashDividendPerShare);
                    devidendCategories.push(v.FinancialYear);
                });

                app.populateChart(dividendData, devidendCategories, 'historical_dividends_chart', "", 80);

                app.Loading.CorporateActions = false;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        populateChart: function (data, category, id, title, pw = 40) {
            var app = this;
            Highcharts.chart(id, {
                chart: {
                    type: "column",
                    backgroundColor: "transparent",
                    style: {
                        color: "#63C5B7",
                    },
                },
                exporting: {
                    enabled: false,
                },
                title: {
                    text: title,
                    style: {
                        color: "#63C5B7",
                    },
                },
                xAxis: {
                    categories: category,
                    text: title,
                    max: category.length < 15 ? category.length - 1 : 15,
                    labels: {
                        style: {
                            color: "#63C5B7",
                        },
                    },
                    lineColor: "#63C5B7",
                },
                yAxis: {
                    title: { enabled: false },
                    opposite: app.Language == "ar",
                    gridLineDashStyle: "dot",
                    gridLineColor: "#63C5B7",
                    labels: {
                        style: {
                            color: "#63C5B7",
                        },
                    },
                },
                plotOptions: {
                    column: {
                        pointPadding: 2,
                        borderWidth: 0,
                    },
                },
                series: [
                    {
                        name: title,
                        data: data,
                        pointWidth: pw,
                        animation: app.Language == "en",
                        color: "#63C5B7",
                        negativeColor: "#63C5B7",
                        tooltip: {
                            valueDecimals: 2,
                        },
                    },
                ],
                legend: {
                    enabled: false,
                },
                annotationsOptions: { enabledButtons: false },
                navigator: { enabled: false },
                scrollbar: { enabled: false },

                responsive: {
                    rules: [{
                        condition: {
                            maxWidth: 500
                        },
                        chartOptions: {
                            series: [
                                {
                                    name: title,
                                    data: data,
                                    pointWidth: pw / 3,
                                    animation: app.Language == "en",
                                    color: "#63C5B7",
                                    negativeColor: "#63C5B7",
                                    tooltip: {
                                        valueDecimals: 2,
                                    },
                                },
                            ],
                        }
                    }]
                }
            });
            $(".highcharts-credits").hide();
        },
        loadSubscription: function (callBack) {
            var app = this;
            this.getAccessToken()
                .then(
                    function (response) {
                        app.fetchSubscriptionData(response);
                        callBack();
                    },
                    function () {
                        app.Loading.Page = false;
                        alert("Unable to connect to Argaam!!!");
                    }
                )
                .catch(function (ex) {
                    alert(ex);
                });
        },
        fetchSubscriptionData: function (accT) {
            var app = this;
            this.getFetch("ir-api/get-alerts/")
                .then((resp) => {
                    app.Alerts = resp.data;
                })
                .catch(function (exception) {
                    console.log("Error:" + exception);
                });
        },
        loadContactIR: function (callBack) {
            var app = this;
            this.getAccessToken()
                .then(
                    function (response) {
                        callBack();
                    },
                    function () {
                        app.Loading.Page = false;
                        alert("Unable to connect to Argaam!!!");
                    }
                )
                .catch(function (ex) {
                    alert(ex);
                });
        },
        loadDisclosures: function (callBack) {
            var app = this;
            this.getAccessToken()
                .then(
                    function (response) {
                        callBack();

                        var hash = window.location.hash;
                        if(!hash.startsWith('#n_'))
                        {
                            app.openDisclosures('disclosures_latestnews');
                        }
                    },
                    function () {
                        app.Loading.Page = false;
                        alert("Unable to connect to Argaam!!!");
                    }
                )
                .catch(function (ex) {
                    alert(ex);
                });
        },
        fetchArticleBody: function (article) {
            var app = this;
            this.getFetch("articles/get-article-amp/" + app.Language + "/" + article.articleID).then(resp => {
                article.body = resp.data.ampReadyBody;
            }).catch(function (exception) {
                console.log('Error:' + exception);
            });
        },
        checkEmailExists: function () {
            var app = this;
            if (app.validEmail(app.AlertSubscriber.email)) {
                this.getFetch("ir-api/check-email/" + app.AlertSubscriber.email)
                    .then((resp) => {
                        if (resp.data.exists) {
                            app.AlertSubscriber.showCode = true;
                        } else {
                            app.AlertSubscriber.showCode = false;
                            app.AlertSubscriber.userMessage = "";
                        }
                    })
                    .catch(function (exception) {
                        console.log("Error:" + exception);
                    });
            }
        },
        subscribe: function () {
            var app = this;
            if (app.isValidToSubscribe()) {
                this.postFetch("ir-api/subscribe-alerts/", app.AlertSubscriber)
                    .then((resp) => {
                        if (app.AlertSubscriber.showCode) {
                            if (resp.data.success) {
                                if (app.Language == "en") {
                                    app.AlertSubscriber.userMessage = "Your subscription is updated successfully";
                                } else {
                                    app.AlertSubscriber.userMessage = "تم تحديث اشتراكك بنجاح";
                                }
                                app.AlertSubscriber.isError = false;
                            } else {
                                if (app.Language == "en") {
                                    app.AlertSubscriber.userMessage = "Unable to update your subscription";
                                } else {
                                    app.AlertSubscriber.userMessage = "غير قادر على تحديث اشتراكك";
                                }
                                app.AlertSubscriber.isError = true;
                            }
                        } else {
                            if (resp.data.success) {
                                if (app.Language == "en") {
                                    app.AlertSubscriber.userMessage = "You are now subscribed, please check your email and confirm your subscription.";
                                } else {
                                    app.AlertSubscriber.userMessage = "أنت الآن مشترك ، يرجى التحقق من بريدك الإلكتروني وتأكيد اشتراكك.";
                                }
                                app.AlertSubscriber.isError = false;
                            } else {
                                if (app.Language == "en") {
                                    app.AlertSubscriber.userMessage = "Unable to subscribe";
                                } else {
                                    app.AlertSubscriber.userMessage = "غير قادر على الاشتراك";
                                }
                                app.AlertSubscriber.isError = true;
                            }
                        }
                        return false;
                    })
                    .catch(function (exception) {
                        console.log("Error:" + exception);
                        app.AlertSubscriber.userMessage =
                            "Unable to subscribe, due to " + exception;
                        app.AlertSubscriber.isError = true;
                    });
            }
        },
        isValidToSubscribe: function () {
            var app = this;
            this.checkEmailExists();
            if (!app.validEmail(app.AlertSubscriber.email)) {
                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "A valid Email address is required";
                } else {
                    app.AlertSubscriber.userMessage = "مطلوب عنوان بريد إلكتروني صالح";

                }
                app.AlertSubscriber.isError = true;
                return false;
            }
            if (app.AlertSubscriber.firstName.trim().length == 0) {
                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "First name is required";
                } else {
                    app.AlertSubscriber.userMessage = "الإسم الأول مطلوب";
                }
                app.AlertSubscriber.isError = true;
                return false;
            }
            if (app.AlertSubscriber.lastName.trim().length == 0) {

                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "Last name is required";
                } else {
                    app.AlertSubscriber.userMessage = "إسم العائلة مطلوب";
                }
                app.AlertSubscriber.isError = true;
                return false;
            }
            if (app.AlertSubscriber.countryName.trim().length == 0) {

                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "Country is required";
                } else {
                    app.AlertSubscriber.userMessage = "اسم الدولة مطلوب";
                }
                app.AlertSubscriber.isError = true;
                return false;
            }
            if (
                app.AlertSubscriber.showCode &&
                app.AlertSubscriber.updateCode.trim().length == 0
            ) {
                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "Please enter the confirmation code to update your subscription";
                } else {
                    app.AlertSubscriber.userMessage = "الرجاء إدخال رمز التأكيد لتحديث اشتراكك";
                }
                app.AlertSubscriber.isError = true;
                return false;
            }
            app.AlertSubscriber.alertTypes = [];
            $(".subscription__form__custom-checkbox__input").each(function (
                i,
                e
            ) {
                if ($(e).prop("checked")) {
                    app.AlertSubscriber.alertTypes.push($(e).attr("data-cont"));
                }
            });
            if (app.AlertSubscriber.alertTypes.length == 0) {
                if (app.Language == "en") {
                    app.AlertSubscriber.userMessage = "You must select at least one Alert Type to subscribe to";
                } else {
                    app.AlertSubscriber.userMessage = "يجب تحديد نوع تنبيه واحد على الأقل للاشتراك فيه";
                }
                app.AlertSubscriber.isError = true;
                return false;
            }

            app.AlertSubscriber.userMessage = "";
            app.AlertSubscriber.isError = false;
            return true;
        },
        resendConformationCode: function () {
            var app = this;
            if (app.validEmail(app.AlertSubscriber.email)) {
                this.getFetch("ir-api/send-code/" + app.AlertSubscriber.email)
                    .then((resp) => {
                        if (resp.data.success) {
                            app.AlertSubscriber.userMessage =
                                "Email containing confirmation code is sent, please check your inbox.";
                        }
                    })
                    .catch(function (exception) {
                        console.log("Error:" + exception);
                    });
            }
        },
        validEmail: function (email) {
            var re =
                /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        },
        isNumber: function isNumber(input) {
            return !isNaN(parseFloat(input));
        },
        getDateString: function (date) {
            return String(date.getFullYear()) + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0');
        },
        getEventForOverView: function () {
            let result = this.CompanyOverview.events;

            result = result.filter((event) => event.descriptionEn.length != 0);

            return result;
        },
        getFinancialHighlightYears: function () {
            var app = this;
            var years = [];
            Object.keys(app.CompanyProfile.financialHighlights[0]).forEach(function (v, i) {
                if (app.isNumber(v)) {
                    years.push(v);
                }
            });
            return years.reverse();
        },
        fomratedValue: function (val, fielName = '') {
            if (val === undefined) {
                return '';
            }
            if (val.value === undefined || val.value === NaN || val.value == '-') {
                return '-';
            }
            var percent = fielName.includes("%") ? " %" : "";
            return (val.value < 0 ? '(' + formatter.format(Math.abs(val.value)) + ')' : formatter.format(val.value)) + percent;
        },
        cssClassForValue: function (val) {
            if (val === undefined || val.value === undefined) {
                return '';
            }
            return val.value < 0 ? 'red' : 'green';
        },
        ChangeCompanyFStatementsPeriodType: function (fiscalPeriodType) {
            $(".financial-statement__tabs li").removeClass("active");
            $(".financial-statement__tabs li[data-cont=" + fiscalPeriodType + "]").addClass("active");

            var app = this;
            app.fetchCompanyFStatementsForPeriod(fiscalPeriodType);
        },
        ChangeCompanyFinancialRatiosPeriodType: function (fiscalPeriodType) {
            $(".financial-ratios__tabs li").removeClass("active");
            $(".financial-ratios__tabs li[data-cont=" + fiscalPeriodType + "]").addClass("active");

            var app = this;
            app.fetchCompanyFRatiosForPeriod(fiscalPeriodType);
        },
        changeCompanyAnalystEstimateFiscalPeriodType: function (fiscalPeriodType) {
            $(".analyst-financial-statement__tabs li").removeClass("active");
            $(".analyst-financial-statement__tabs li[data-cont=" + fiscalPeriodType + "]").addClass("active");

            var app = this;
            app.fetchCompanyAnalystEstimates('', fiscalPeriodType);
        },
        ChangeCorporateActionTabs: function (event) {
            $(".main-corporate-actions__tabs li").removeClass("active");
            $(".main-corporate-actions__container div").hide();

            var $target = $(event.target);
            var tab = $target.attr("data-cont");

            $target.addClass("active");
            $("." + tab).show();
        },
        showSegments: function (segmentName) {
            $(".segments-details").hide();
            $(".business-segments__tabs li").removeClass("active-tab");
            $(segmentName + "-tab").addClass("active-tab");
            $(segmentName).show();
        },
        changeIPReportType: function (event) {
            var reportType = event.target.value;

            this.fetchCompanyInvestorPresentation('', reportType);
        },
        setCurrencyFinancialHighlight: function (cur) {
            var app = this;
            $("[data-cont='Financials_Highlights__Riyal']").removeClass("active");
            $("[data-cont='Financials_Highlights__USD']").removeClass("active");
            $("[data-cont='Financials_Highlights__" + cur + "']").addClass("active");

            $(".Financials-Highlights__currency__type-en").html("(M " + cur + ")");
            $(".Financials-Highlights__currency__type-ar").html("( مليون " + (cur == "USD" ? "دولار" : "ريال") + ")");

            var years = app.getFinancialHighlightYears();

            app.CompanyProfile.financialHighlights.forEach(function (fn, i) {
                years.forEach(function (y) {
                    fn[y] = app.convertToCurrency(fn[y], fn.Currency, cur);
                    console.log(fn.FSFieldName + ' ' + y + ' : ' + fn[y]);
                });
                fn.Currency = cur;
            });
        },
        setCurrencyStockInformation: function (curTo) {
            if (!$("[data-cont='stock-information__" + curTo + "']").hasClass("active")) {
                var app = this;
                $("[data-cont='stock-information__Riyal']").removeClass("active");
                $("[data-cont='stock-information__USD']").removeClass("active");
                $("[data-cont='stock-information__" + curTo + "']").addClass("active");

                var curFrom = curTo == 'Riyal' ? 'USD' : 'Riyal';
                if (this.Language == 'ar') {
                    $(".StockInformationCurrencySymbol").html(curTo == "USD" ? "دولار" : "ريال");
                } else {
                    $(".StockInformationCurrencySymbol").html(curTo);
                }

                app.CompanyProfile.stockInfo.nominalValue = app.convertToCurrency(app.CompanyProfile.stockInfo.nominalValue, curFrom, curTo);
                app.CompanyProfile.stockInfo.bookValue = app.convertToCurrency(app.CompanyProfile.stockInfo.bookValue, curFrom, curTo);
                //app.CompanyProfile.stockInfo.marketValue = app.convertToCurrency(app.CompanyProfile.stockInfo.marketValue, curFrom, curTo);
            }
        },
        setCurrencyFinancialStatement: function (cur) {
            var app = this;
            $("[data-cont='main-financial-statement__riyal']").removeClass("active");
            $("[data-cont='main-financial-statement__usd']").removeClass("active");
            $("[data-cont='main-financial-statement__" + cur.toLowerCase() + "']").addClass("active");
            if (this.Language == 'ar') {
                $(".financialStatementsCurrencySymbol").html(cur == "USD" ? "دولار" : "ريال");
            } else {
                $(".financialStatementsCurrencySymbol").html(cur);
            }
            app.CompanyFStatements.tabs.forEach(function (tab) {
                tab.fields.forEach(function (field) {
                    if (field.isCurrency) {
                        field.values.forEach(function (value) {
                            value.value = app.convertToCurrency(value.value, field.currency, cur);
                        });
                        field.currency = cur;
                    }
                });
            });
        },
        setCurrencyFinancialRatios: function (cur) {
            var app = this;
            $("[data-cont='main-financial-ratios__USD']").removeClass("active");
            $("[data-cont='main-financial-ratios__Riyal']").removeClass("active");
            $("[data-cont='main-financial-ratios__" + cur + "']").addClass("active");
            if (this.Language == 'ar') {
                $(".financialRatiosCurrencySymbol").html(cur == "USD" ? "دولار" : "ريال");
            } else {
                $(".financialRatiosCurrencySymbol").html(cur);
            }

            app.CompanyFRatios.financialRatioFieldsGroups.forEach(function (fg) {
                fg.financialRatioFieldsGroupFields.forEach(function (field) {
                    if (field.isCurrency) {
                        field.values.forEach(function (value) {
                            if (value.value !== '-') {
                                value.value = app.convertToCurrency(value.value, field.currency, cur);
                            }
                        });
                        field.currency = cur;
                    }
                });
            });
        },
        setCurrencyAnalystEstimates: function (cur) {
            if (!$("[data-cont='analyst-financial-statement_AE__" + cur + "']").hasClass("active")) {
                var app = this;
                $(".analyst-financial-statement__title__options__tabs li").removeClass("active");

                $("[data-cont='analyst-financial-statement_AE__" + cur + "']").addClass("active");

                $(".ra_ae-currency").html("Million " + cur);

                var curFrom = cur == 'Riyal' ? 'USD' : 'Riyal';

                app.CompanyAnalystEstimates.tabs.forEach(function (tab) {
                    tab.fieldsValues.forEach(function (field) {
                        field.periodValues.forEach(function (value) {
                            value.estimatedValue = app.convertToCurrency(value.estimatedValue, curFrom, cur);
                            value.actualValue = app.convertToCurrency(value.actualValue, curFrom, cur);
                        });
                    });
                });
            }
        },
        chartOptionChanged: function () {
            var period = $("#chart_perid").val();
            var type = $("#chart_type").val();
            var app = this;
            app.fetchMainChart(type);
        },
        convertToCurrency: function (value, from, to) {
            var exchangeRate = {
                'RIYAL-USD': 0.266333,
                'SAR-USD': 0.266333,
                'USD-RIYAL': 3.7546980659550262,
                'USD-SAR': 3.7546980659550262,
                'RIYAL-RIYAL': 1.000,
                'RIYAL-SAR': 1.000,
                'SAR-RIYAL': 1.000,
                'SAR-SAR': 1.000,
                'USD-USD': 1.000
            };
            var c = from.toUpperCase() + '-' + to.toUpperCase();
            var rate = exchangeRate[c];

            return value * rate;
        },
        convertToCurrency_new: function (value, from, to) {
            var exchangeRate = { 'SAR-USD': 0.266333, 'USD-SAR': 3.7546980659550262, 'SAR-SAR': 1.000, 'USD-USD': 1.000 };
            var c = from.toUpperCase() + '-' + to.toUpperCase();
            var rate = exchangeRate[c];

            return value * rate;
        },
        toPascalCase: function (string) {
            return `${string}`
                .toLowerCase()
                .replace(new RegExp(/[-_]+/, 'g'), ' ')
                .replace(new RegExp(/[^\w\s]/, 'g'), '')
                .replace(
                    new RegExp(/\s+(.)(\w*)/, 'g'),
                    ($1, $2, $3) => `${$2.toUpperCase() + $3}`
                )
                .replace(new RegExp(/\w/), s => s.toUpperCase());
        },
        printPage: function () {
            window.print();
            return false;
        },
        formatDate: function (date) {
            if (!isNaN(date)) {
                var d = new Date(date),
                    month = '' + (d.getMonth() + 1),
                    day = '' + d.getDate(),
                    year = d.getFullYear();

                if (month.length < 2)
                    month = '0' + month;
                if (day.length < 2)
                    day = '0' + day;

                return [day, month, year].join('-');
            }
            else return "";
        },
        parseAndFormatDate: function (str) {
            if (!str || str.toString().length < 5) {
                return str;
            }
            else {
                str = str.toString();

                var y = str.substr(0, 4);
                var m = str.substr(5, 2);
                var d = str.substr(8, 2);
                return this.formatDate(date = new Date(y, m - 1, d));
            }
        },
        parseAndFormatDateDDMMYYYY: function (str) {
            if (!str || str.length < 5) {
                return str;
            }
            else {
                var d = str.substr(0, 2);
                var m = str.substr(3, 2);
                var y = str.substr(6, 4);
                return this.formatDate(date = new Date(y, m - 1, d));
            }
        },
        parseAndFormatDateDDMMYY: function (str) {
            if (!str || str.length < 5) {
                return str;
            }
            else {
                var d = str.substr(0, 2);
                var m = str.substr(3, 2);
                var y = "20" + str.substr(6, 2);
                return this.formatDate(date = new Date(y, m - 1, d));
            }
        },
        parseAndFormatDateMMDDYYYY: function (str) {
            if (!str || str.length < 5) {
                return str;
            }
            else {
                var m = str.substr(0, 2);
                var d = str.substr(3, 2);
                var y = str.substr(6, 4);
                return this.formatDate(date = new Date(y, m - 1, d));
            }
        },
        GetMonthName: function (monthNumber) {
            return this.Language == "en" ? this.MonthFullNameEn[monthNumber - 1] : this.MonthNames[monthNumber - 1];
        },
        showMobileMenu: function (e) {
            $(".overlay-container").addClass("show");
        },
        hideMobileMenu: function (e) {
            $(".overlay-container").removeClass("show");
        },
        showEventPopup: function (calenderEvent) {
            var app = this;
            app.SelectedEvent = calenderEvent;
            $(".calender__popup--overlay").css("display", "flex");
        },
        closeEventPopup: function () {
            $(".calender__popup--overlay").css("display", "none");
        },
        scrollTable: function (table, steps) {
            var offset = $("." + table).scrollLeft() + steps;
            $("." + table).scrollLeft(offset);
        },
        getCompanyFinancialResult: function (forYear, fiscalPeriodValueID, lang) {
            var filter = {
                forYear,
                fiscalPeriodValueID
            };

            const result = this.CompanyFStatements.companyFinancialResults.filter(function (fr) {
                for (var key in filter) {
                    if (fr[key] === undefined || fr[key] != filter[key])
                        return false;
                }
                return true;
            });

            return result.length > 0 ? lang == "ar" ? result[0].fileURLAr : result[0].fileURLEn : "#";
        },
        getLocalizedCurrencySymbol: function (currency) {
            if (this.Language == 'ar') {
                return currency == "USD" || currency == "usd" ? "دولار" : "ريال";
            } else {
                return currency;
            }
        },
        getRiyalValue: function (avalue, currency) {
            if (currency.includes('USD')) {
                var v = this.convertToCurrency(avalue, 'USD', 'RIYAL');

                return formatter.format(v);
            }
            else return avalue;
        },
        openDisclosures: function (disclosures_content) {
            $(".disclosures__container__tabs li").removeClass("active-tab");
            $(".disclosures__container__tabs ." + disclosures_content).addClass("active-tab");

            $(".disclosures__container__content li").hide();

            if (disclosures_content == 'disclosures_calendar' || $(".disclosures__container__content ." + disclosures_content).length > 1) {
                $(".disclosures__container__content ." + disclosures_content).show();
            }
            else {
                var app = this;

                clearTimeout(app.disclosureTimeout);
                app.disclosureTimeout = setTimeout(() => {
                    app.openDisclosures(disclosures_content);
                }, 1000);
            }
        },
        toFileURL: function (fileURL) {
            return fileURL ? fileURL : "#";
        }
    }
});