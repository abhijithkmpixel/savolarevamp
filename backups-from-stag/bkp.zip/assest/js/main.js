// Navigation-Bar Desktop //
$(document).ready(function () {
  let navbarLinks = $(".nav-container__desktop__links__link");
  let navbarMobileLinks = $(".nav-container__mobile__body__link");

  $(navbarLinks).click(function () {
    $(navbarLinks).removeClass("active");
    $(this).addClass("active");
  });

  $(navbarMobileLinks).click(function () {
    $(navbarMobileLinks).removeClass("active");
    $(this).addClass("active");
  });
});
// Navigation-Bar Mobile //
$(document).ready(function () {
  let desktopMenuBtn = $(".nav-container__desktop__bar");
  let mobileMenuBtn = $(".nav-container__mobile__header__btn");
  let mobileMenu = $(".nav-container__mobile");

  $(desktopMenuBtn).click(function () {
    $(mobileMenu).css("transform", "translate(0%,0%)");
  });

  $(mobileMenuBtn).click(function () {
    $(mobileMenu).css("transform", "translate(100%,0%)");
  });
});
// Desktop Tabs //
let tabs = document.querySelectorAll(".tabs li");
let tabsArray = Array.from(tabs);
let divs = document.querySelectorAll(".widgets-container > div");
let divsArray = Array.from(divs);
tabsArray.forEach((ele) => {
  ele.addEventListener("click", function (e) {
    var currentTab = this.innerText;
    itemName.text(currentTab);
    tabsArray.forEach((ele) => {
      ele.classList.remove("active");
      overlayCont.classList.remove("show");
      $("body").css("overflow-y", "scroll");
    });
    e.currentTarget.classList.add("active");
    divsArray.forEach((div) => {
      div.style.display = "none";
    });
    document.querySelector(e.currentTarget.dataset.cont).style.display =
      "block";
  });
});
// Mobile Tabs //
var overlayCont = document.querySelector(".overlay-container");
var overlayInner = document.querySelector(".overlay-inner");
var wClose = document.getElementById("wClose");
var item = $(".item");
var itemName = $(".item span");
item.click(function () {
  overlayCont.classList.add("show");
  $("body").css("overflow-y", "hidden");
});
wClose.addEventListener("click", function () {
  overlayCont.classList.remove("show");
  $("body").css("overflow-y", "scroll");
});

overlayCont.addEventListener("click", function (e) {
  if (e.target == overlayCont) {
    overlayCont.classList.remove("show");
    $("body").css("overflow-y", "scroll");
  }
});

/* End of Layout */

/* Overview Page  */
/* Ticker Tabs*/
$(function () {
  var activeIndex = $(".active").index(),
    $tickerlis = $(".ticker-container ul"),
    $tickerTabs = $(".ticker-tab li");

  // Show content of active tab on loads
  $tickerlis.eq(activeIndex).show();

  $(".ticker-tab").on("click", "li", function (e) {
    var $current = $(e.currentTarget),
      index = $current.index();

    $tickerTabs.removeClass("active");
    $current.addClass("active");
    $tickerlis.hide().eq(index).show();
  });
});


/* End of Overview Page  */

$(function () {
  var activeIndex = $(".active-tab").index(),
    $contentlis = $(".corporate-actions__container ul"),
    $tabslis = $(".corporate-actions__tabs li");

  // Show content of active tab on loads
  $contentlis.eq(activeIndex).show();

  $(".corporate-actions__tabs").on("click", "li", function (e) {
    var $current = $(e.currentTarget),
      index = $current.index();

    $tabslis.removeClass("active-tab");
    $current.addClass("active-tab");
    $contentlis.hide().eq(index).show();
  });
});

// Currency Tabs Active Class //
$(".financial-statement__options__tabs li").click(function () {
  $(".financial-statement__options__tabs li").removeClass("active");
  $(this).addClass("active");
});
// English Currency Type //
$(".financial-statement__options__tabs__usd-en").click(function () {
  $(".st-currency-en").text("USD");
});
$(".financial-statement__ptions__tabs__riyal-en").click(function () {
  $(".st-currency-en").text("SAR");
});
// Arabic Currenncy Type //
$(".financial-statement__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-statement__options__tabs__riyal-ar").click(function () {
  $(".st-currency-ar").text("ريال");
});

/*     Financial Statement Table    */
///////////////////////////////////// Financial Statemenets Tab ///////////////////////////////

/* Main Financial statement tabs currency */

$(".main-financial-statement__title__options__tabs li").click(function () {
  $(".main-financial-statement__title__options__tabs li").removeClass("active");
  $(this).addClass("active");
});

// English Currency //
$(".main-financial-statement__title__options__tabs__usd").click(function () {
  $(".ra-currency").text("USD");
});
$(".main-financial-statement__title__options__tabs__riyal").click(
  function () {
    $(".ra-currency").text("Riyal");
  }
);

// Arabic Currency //
$(".main-financial-statement__title__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".main-financial-statement__title__options__tabs__riyal-ar").click(
  function () {
    $(".st-currency-ar").text("ريال");
  }
);

/*  end of Main Financial statement tabs currency */

/* fs-annual-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_annual_Parent = $(".fs-annual .scroll-container");
  //Start the scrolling process
  $(".fs-annual-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fs-annual-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fs-annual .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fs-annual-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_annual_Parent.scrollLeft() + scrollStep * modifier;

        fs_annual_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fs-annual-scroll scroll */

/* fs-quarter-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_quarter_Parent = $(".fs-quarter .scroll-container");
  //Start the scrolling process
  $(".fs-quarter-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fs-quarter-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fs-quarter .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fs-quarter-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_quarter_Parent.scrollLeft() + scrollStep * modifier;

        fs_quarter_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fs-quarter-scroll scroll */

/* fs-interim-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_interim_Parent = $(".fs-interim .scroll-container");
  //Start the scrolling process
  $(".fs-interim-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fs-interim-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fs-interim .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fs-interim-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_interim_Parent.scrollLeft() + scrollStep * modifier;

        fs_interim_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fs-interim-scroll scroll */

/////////////////////////////// End Of Financial Statemenets Tab //////////////////////////////////////


/* accordion menu */
function showHideChild(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");

    $("#btn" + fieldID).data("childviewstatus", "close");

    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).show();
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}

function showHideSubStatement(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");
    $("#btn" + fieldID).data("childviewstatus", "close");
    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      if ($(this).data("ischildelement") == "no") {
        $(this).show();
      }
      if ($(this).data("haschildelementdata") == "yes") {
        var fldID = $(this).attr("id");
        fldID = fldID.substring(2);
        $("#tr" + fldID)
          .removeClass("fTrOpen")
          .addClass("fTrClose");
        $("#btn" + fldID)
          .removeClass("fOpen")
          .addClass("fClose");
        $("#btn" + fldID).data("childviewstatus", "close");
      }
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}

/* end of accordion menu */

// requires jquery library
jQuery(document).ready(function() {
   jQuery(".main-table").clone(true).appendTo('#table-scroll').addClass('clone');   
 });


/*    End Of Business Segments Page  */

/* Analyst Coverage Page */
/* Analyst Tabs */
$(function () {

  var activeIndex = $('.active-tab').index(),
      $contentlis = $('.analyst-coverage__tab-content .analyst-coverage__tab-content--list'),
      $tabslis = $('.analyst-coverage__tabs .analyst-coverage__tabs--header');
  
  // Show content of active tab on loads
  $contentlis.eq(activeIndex).show();

  $('.analyst-coverage__tabs').on('click', '.analyst-coverage__tabs--header', function (e) {
    var $current = $(e.currentTarget),
        index = $current.index();
    
    $tabslis.removeClass('active-tab');
    $current.addClass('active-tab');
    $contentlis.hide().eq(index).show();
	 });
});

/* Analyst Estimates Financial Statments  */
$(function () {
  var activeAnalyst = $(".active-tab").index(),
    $FinacialAnaylstContent = $(".financial-statement__content li"),
    $FinacialAnalystTabs = $(".financial-statement__tabs li");

  // Show content of active tab on loads
  $FinacialAnaylstContent.eq(activeAnalyst).show();

  $(".financial-statement__tabs").on("click", "li", function (e) {
    var $current = $(e.currentTarget),
      index = $current.index();

    $FinacialAnalystTabs.removeClass("active-tab");
    $current.addClass("active-tab");
    $FinacialAnaylstContent.hide().eq(index).show();
  });
});

// Currency Tabs Active Class //
$(".financial-statement__options__tabs li").click(function () {
  $(".financial-statement__options__tabs li").removeClass("active");
  $(this).addClass("active");
});
// English Currency Type //
$(".financial-statement__options__tabs__usd-en").click(function () {
  $(".st-currency-en").text("USD");
});
$(".financial-statement__ptions__tabs__riyal-en").click(function () {
  $(".st-currency-en").text("SAR");
});
// Arabic Currenncy Type //
$(".financial-statement__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-statement__options__tabs__riyal-ar").click(function () {
  $(".st-currency-ar").text("ريال");
});

/*     Financial Statement Table    */
///////////////////////////////////// Financial Statemenets Tab ///////////////////////////////

/* fS chart popup */
$(".as-chart-btn").click(function () {
  $("body").addClass("hide-scroll");
  $(".as-popup").show();
});
$(".as-popup__overlay__chart__close img").click(function () {
  $("body").removeClass("hide-scroll");
  $(".as-popup").hide();
});
var as_Popup = document.querySelector(".as-popup__overlay");
as_Popup.addEventListener("click", function (e) {
  if (e.target == as_Popup) {
    $(".as-popup").hide();
    $("body").removeClass("hide-scroll");
  }
});
/* End of fS chart popup */

/* Main Financial statement tabs currency */

$(".analyst-financial-statement__title__options__tabs li").click(function () {
  $(".analyst-financial-statement__title__options__tabs li").removeClass("active");
  $(this).addClass("active");
});

// English Currency //
$(".analyst-financial-statement__title__options__tabs__usd").click(function () {
  $(".ra-currency").text("USD");
});
$(".analyst-financial-statement__title__options__tabs__riyal").click(
  function () {
    $(".ra-currency").text("Riyal");
  }
);

// Arabic Currency //
$(".analyst-financial-statement__title__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".analyst-financial-statement__title__options__tabs__riyal-ar").click(
  function () {
    $(".st-currency-ar").text("ريال");
  }
);

/*  end of Main Financial statement tabs currency */

/* Main Financial statement tabs */
let analystFinancialstatementTabs = document.querySelectorAll(
  ".analyst-financial-statement__tabs li"
);
let analystFinancialstatementTabsArray = Array.from(analystFinancialstatementTabs);
let analystFinancialstatementDivs = document.querySelectorAll(
  "#analystFinancialStatement > div"
);
let analystFinancialstatementDivsArray = Array.from(analystFinancialstatementDivs);
analystFinancialstatementTabsArray.forEach((ele) => {
  ele.addEventListener("click", function (e) {
    analystFinancialstatementTabsArray.forEach((ele) => {
      ele.classList.remove("active");
    });
    e.currentTarget.classList.add("active");
    analystFinancialstatementDivsArray.forEach((div) => {
      div.style.display = "none";
    });
    document.querySelector(e.currentTarget.dataset.cont).style.display =
      "block";
  });
});
/* End Of Main Financial statement tabs */

/* as-annual-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_annual_Parent = $(".as-annual .scroll-container");
  //Start the scrolling process
  $(".as-annual-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".as-annual-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".as-annual .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".as-annual-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_annual_Parent.scrollLeft() + scrollStep * modifier;

        fs_annual_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of as-annual-scroll scroll */

/* as-quarter-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_quarter_Parent = $(".as-quarter .scroll-container");
  //Start the scrolling process
  $(".as-quarter-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".as-quarter-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".as-quarter .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".as-quarter-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_quarter_Parent.scrollLeft() + scrollStep * modifier;

        fs_quarter_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of as-quarter-scroll scroll */



/////////////////////////////// End Of Financial Statemenets Tab //////////////////////////////////////

/* accordion menu */
function showHideChild(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");

    $("#btn" + fieldID).data("childviewstatus", "close");

    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).show();
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}

function showHideSubStatement(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");
    $("#btn" + fieldID).data("childviewstatus", "close");
    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      if ($(this).data("ischildelement") == "no") {
        $(this).show();
      }
      if ($(this).data("haschildelementdata") == "yes") {
        var fldID = $(this).attr("id");
        fldID = fldID.substring(2);
        $("#tr" + fldID)
          .removeClass("fTrOpen")
          .addClass("fTrClose");
        $("#btn" + fldID)
          .removeClass("fOpen")
          .addClass("fClose");
        $("#btn" + fldID).data("childviewstatus", "close");
      }
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}

/* end of accordion menu */

// requires jquery library
jQuery(document).ready(function() {
   jQuery(".main-table").clone(true).appendTo('#table-scroll').addClass('clone');   
 });

/* End of Analyst Coverage Page */

/*  Merges & Acquistions Page */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    historicalTradingDataParent = $(
      ".merges-data__data__container"
    );
  $(".merges-data__data__panner").on(
    "mouseenter touchstart",
    function () {
      var data = $(this).data("scrollModifier"),
        direction = parseInt(data, 10);
      $(this).addClass("active-scroll");
      startScrolling(direction, scrollStep);
    }
  );
  $(".merges-data__data__panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".merges-data__data__container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".merges-data__data__panner").removeClass("active-scroll");
    }
  );
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset =
          historicalTradingDataParent.scrollLeft() + scrollStep * modifier;

        historicalTradingDataParent.scrollLeft(newOffset);
      }, 10);
    }
  }
  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();


$(function() {
  $('input[name="datefilter3"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});


$( "#calender--merges" ).click(function(event){
  $(this).removeAttr('readonly').select();
});

$( "#calender--merges" ).blur(function(event){
  $(this).attr('readonly', 'readonly');
});

/* End of Merges & Acquistions Page */

/*  Financial Statments Page     */
$(function () {
  var activeFinancial = $(".active-tab").index(),
    $FinacialStatmentContent = $(".financial-statement__content li"),
    $FinacialstatmentTabs = $(".financial-statement__tabs li");
  // Show content of active tab on loads
  $FinacialStatmentContent.eq(activeFinancial).show();

  $(".financial-statement__tabs").on("click", "li", function (e) {
    var $current = $(e.currentTarget),
      index = $current.index();

    $FinacialstatmentTabs.removeClass("active-tab");
    $current.addClass("active-tab");
    $FinacialStatmentContent.hide().eq(index).show();
  });
});
// Currency Tabs Active Class //
$(".financial-statement__options__tabs li").click(function () {
  $(".financial-statement__options__tabs li").removeClass("active");
  $(this).addClass("active");
});
// English Currency Type //
$(".financial-statement__options__tabs__usd-en").click(function () {
  $(".st-currency-en").text("USD");
});
$(".financial-statement__ptions__tabs__riyal-en").click(function () {
  $(".st-currency-en").text("SAR");
});
// Arabic Currenncy Type //
$(".financial-statement__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-statement__options__tabs__riyal-ar").click(function () {
  $(".st-currency-ar").text("ريال");
});
/*     Financial Statement Table    */
///////////////////////////////////// Financial Statemenets Tab ///////////////////////////////
/* fS chart popup */
$(".fn-chart-btn").click(function () {
  $("body").addClass("hide-scroll");
  $(".fn-popup").show();
});
$(".fn-popup__overlay__chart__close img").click(function () {
  $("body").removeClass("hide-scroll");
  $(".fn-popup").hide();
});
var fs_Popup = document.querySelector(".fn-popup__overlay");
fs_Popup.addEventListener("click", function (e) {
  if (e.target == fs_Popup) {
    $(".fn-popup").hide();
    $("body").removeClass("hide-scroll");
  }
});
/* End of fS chart popup */

/*  Financial statement tabs currency */

$(".financial-statement__title__options__tabs li").click(function () {
  $(".financial-statement__title__options__tabs li").removeClass("active");
  $(this).addClass("active");
});

// English Currency //
$(".financial-statement__title__options__tabs__usd").click(function () {
  $(".ra-currency").text("USD");
});
$(".financial-statement__title__options__tabs__riyal").click(
  function () {
    $(".ra-currency").text("Riyal");
  }
);

// Arabic Currency //
$(".financial-statement__title__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-statement__title__options__tabs__riyal-ar").click(
  function () {
    $(".st-currency-ar").text("ريال");
  }
);

/*  end of  Financial statement tabs currency */

/*  Financial statement tabs */
let FinancialstatementTabs = document.querySelectorAll(
  ".financial-statement__tabs li"
);
let FinancialstatementTabsArray = Array.from(FinancialstatementTabs);
let FinancialstatementDivs = document.querySelectorAll(
  "#financialStatement > div"
);
let FinancialstatementDivsArray = Array.from(FinancialstatementDivs);
FinancialstatementTabsArray.forEach((ele) => {
  ele.addEventListener("click", function (e) {
    FinancialstatementTabsArray.forEach((ele) => {
      ele.classList.remove("active");
    });
    e.currentTarget.classList.add("active");
    FinancialstatementDivsArray.forEach((div) => {
      div.style.display = "none";
    });
    document.querySelector(e.currentTarget.dataset.cont).style.display =
      "block";
  });
});
/* End Of Financial statement tabs */

/* annual-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    annual_Parent = $(".annual .scroll-container");
  //Start the scrolling process
  $(".annual-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".annual-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".annual .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".annual-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = annual_Parent.scrollLeft() + scrollStep * modifier;

        annual_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of annual-scroll scroll */

/* fs-quarter-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    quarter_Parent = $(".quarter .scroll-container");
  //Start the scrolling process
  $(".quarter-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".quarter-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".quarter .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".quarter-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = quarter_Parent.scrollLeft() + scrollStep * modifier;

        quarter_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fs-quarter-scroll scroll */

/* fs-interim-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    interim_Parent = $(".interim .scroll-container");
  //Start the scrolling process
  $(".interim-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".interim-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".interim .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".interim-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = interim_Parent.scrollLeft() + scrollStep * modifier;

        interim_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fs-interim-scroll scroll */
/////////////////////////////// End Of Financial Statemenets Tab //////////////////////////////////////
/* accordion menu */
function showHideChild(fieldID) {
  var openAccordian =
    JSON.parse(sessionStorage.getItem("openAccordian")) || [];
  if ($("#btn" + fieldID).data("childviewstatu") == "openn") {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");

    $("#btn" + fieldID).data("childviewstatu", "close");

    openAccordian = jQuery.grep(openAccordian, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordian", JSON.stringify(openAccordian));
  } else {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).show();
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatu", "openn");
    if (openAccordian.indexOf("#btn" + fieldID) == -1) {
      openAccordian.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordian", JSON.stringify(openAccordian));
    }
  }
  return false;
}

function showHideStatement(fieldID) {
  var openAccordian =
    JSON.parse(sessionStorage.getItem("openAccordian")) || [];
  if ($("#btn" + fieldID).data("childviewstatu") == "openn") {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");
    $("#btn" + fieldID).data("childviewstatu", "close");
    openAccordian = jQuery.grep(openAccordian, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordian", JSON.stringify(openAccordian));
  } else {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      if ($(this).data("ischildelement") == "no") {
        $(this).show();
      }
      if ($(this).data("haschildelementdata") == "yes") {
        var fldID = $(this).attr("id");
        fldID = fldID.substring(2);
        $("#tr" + fldID)
          .removeClass("fTrOpen")
          .addClass("fTrClose");
        $("#btn" + fldID)
          .removeClass("fOpen")
          .addClass("fClose");
        $("#btn" + fldID).data("childviewstatu", "close");
      }
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatu", "openn");
    if (openAccordian.indexOf("#btn" + fieldID) == -1) {
      openAccordian.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordian", JSON.stringify(openAccordian));
    }
  }
  return false;
}

/* end of accordion menu */

// requires jquery library
jQuery(document).ready(function() {
   jQuery(".main-table").clone(true).appendTo('#table-scroll').addClass('clone');   
});
 
// Nested According Table
$(document).ready(function () {
  $(".nested").click(function (e) {
    $(this).toggleClass('nClose');
    $(this).parent().parent().nextUntil(".trx").toggleClass("nested2");
  });
});
/*   End of Financial Statments Page     */

// Capital Changes scroll //
(function () {
    var scrollHandle = 0,
        scrollStep = 2,
        capitalChangesParent = $('.main-corporate-actions__capital-changes');
    $(".main-corporate-actions__panner").on("mouseenter touchstart", function () {
        var data = $(this).data('scrollModifier'),
            direction = parseInt(data, 10);
        $(this).addClass('active-scroll');
        startScrolling(direction, scrollStep);
    });
    $(".main-corporate-actions__panner").on("mouseleave", function () {
        stopScrolling();
        $(this).removeClass('active-scroll');
    });
    $(".main-corporate-actions__capital-changes").on("touchstart click mouseenter", function () {
        stopScrolling();
        $(".main-corporate-actions__panner").removeClass('active-scroll');
    });
    function startScrolling(modifier, step) {
        if (scrollHandle === 0) {
            scrollHandle = setInterval(function () {
                var newOffset = capitalChangesParent.scrollLeft() + (scrollStep * modifier);

                capitalChangesParent.scrollLeft(newOffset);
            }, 10);
        }
    }
    function stopScrolling() {
        clearInterval(scrollHandle);
        scrollHandle = 0;
    }
}());
// Dividend History scroll //
(function () {
    var scrollHandle = 0,
        scrollStep = 2,
        dividendHistoryParent = $('.main-corporate-actions__dividend-history');
    $(".main-corporate-actions__panner").on("mouseenter touchstart", function () {
        var data = $(this).data('scrollModifier'),
            direction = parseInt(data, 10);
        $(this).addClass('active-scroll');
        startScrolling(direction, scrollStep);
    });
    $(".main-corporate-actions__panner").on("mouseleave", function () {
        stopScrolling();
        $(this).removeClass('active-scroll');
    });
    $(".main-corporate-actions__dividend-history").on("touchstart click mouseenter", function () {
        stopScrolling();
        $(".main-corporate-actions__panner").removeClass('active-scroll');
    });
    function startScrolling(modifier, step) {
        if (scrollHandle === 0) {
            scrollHandle = setInterval(function () {
                var newOffset = dividendHistoryParent.scrollLeft() + (scrollStep * modifier);

                dividendHistoryParent.scrollLeft(newOffset);
            }, 10);
        }
    }
    function stopScrolling() {
        clearInterval(scrollHandle);
        scrollHandle = 0;
    }
}());
/* End of Corporate Actions Page */

/* Financial Reports Page */
// Financial Reports Scroll //
(function () {
    var scrollHandle = 0,
        scrollStep = 2,
        financialReportsParent = $('.financial-reports__container');
    $(".financial-reports__panner").on("mouseenter touchstart", function () {
        var data = $(this).data('scrollModifier'),
            direction = parseInt(data, 10);
        $(this).addClass('active-scroll');
        startScrolling(direction, scrollStep);
    });
    $(".financial-reports__panner").on("mouseleave", function () {
        stopScrolling();
        $(this).removeClass('active-scroll');
        $(".financial-reports__container").on("touchstart click mouseenter", function () {
            stopScrolling();
            $(".financial-reports__panner").removeClass('active-scroll');
        });
    });
    function startScrolling(modifier, step) {
        if (scrollHandle === 0) {
            scrollHandle = setInterval(function () {
                var newOffset = financialReportsParent.scrollLeft() + (scrollStep * modifier);
                financialReportsParent.scrollLeft(newOffset);
            }, 10);
        }
    }
    function stopScrolling() {
        clearInterval(scrollHandle);
        scrollHandle = 0;
    }
}());
/* End of Financial Reports Page */

/*  Financial Ratios Page  */


$(function () {
  var activeFinancialRatios = $(".active-tab").index(),
    $FinacialRatiosContent = $(".financial-statement__content li"),
    $FinacialRatiosTabs = $(".financial-ratios__tabs li");

  // Show content of active tab on loads
  $FinacialRatiosContent.eq(activeFinancialRatios).show();

  $(".financial-ratios__tabs").on("click", "li", function (e) {
    var $current = $(e.currentTarget),
      index = $current.index();

    $FinacialRatiosTabs.removeClass("active-tab");
    $current.addClass("active-tab");
    $FinacialRatiosContent.hide().eq(index).show();
  });
});

// Currency Tabs Active Class //
$(".financial-ratios__tabs li").click(function () {
  $(".financial-ratios__tabs li").removeClass("active");
  $(this).addClass("active");
});
// English Currency Type //
$(".financial-ratios__options__tabs__usd-en").click(function () {
  $(".st-currency-en").text("USD");
});
$(".financial-statement__ptions__tabs__riyal-en").click(function () {
  $(".st-currency-en").text("SAR");
});
// Arabic Currenncy Type //
$(".financial-ratios__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-ratios__options__tabs__riyal-ar").click(function () {
  $(".st-currency-ar").text("ريال");
});

/*     Financial Statement Table    */
///////////////////////////////////// Financial Statemenets Tab ///////////////////////////////

/* fS chart popup */
$(".fr-chart-btn").click(function () {
  $("body").addClass("hide-scroll");
  $(".fr-popup").show();
});
$(".fr-popup__overlay__chart__close img").click(function () {
  $("body").removeClass("hide-scroll");
  $(".fr-popup").hide();
});
var fr_Popup = document.querySelector(".fr-popup__overlay");
fr_Popup.addEventListener("click", function (e) {
  if (e.target == fr_Popup) {
    $(".fr-popup").hide();
    $("body").removeClass("hide-scroll");
  }
});
/* End of fS chart popup */

/* Main Financial statement tabs currency */

$(".financial-ratios__title__options__tabs li").click(function () {
  $(".financial-ratios__title__options__tabs li").removeClass("active");
  $(this).addClass("active");
});

// English Currency //
$(".financial-ratios__title__options__tabs__usd").click(function () {
  $(".ra-currency").text("USD");
});
$(".financial-ratios__title__options__tabs__riyal").click(
  function () {
    $(".ra-currency").text("Riyal");
  }
);

// Arabic Currency //
$(".financial-ratios__title__options__tabs__usd-ar").click(function () {
  $(".st-currency-ar").text("دولار");
});
$(".financial-ratios__title__options__tabs__riyal-ar").click(
  function () {
    $(".st-currency-ar").text("ريال");
  }
);

/*  end of Main Financial statement tabs currency */

/* Main Financial statement tabs */
let mainFinancialsRatiosTabs = document.querySelectorAll(
  ".financial-ratios__tabs li"
);
let mainFinancialRatiosTabsArray = Array.from(mainFinancialsRatiosTabs);
let FinancialRatiosDivs = document.querySelectorAll(
  "#financialRatios > div"
);
let FinancialsRatiosDivsArray = Array.from(FinancialRatiosDivs);
mainFinancialRatiosTabsArray.forEach((ele) => {
  ele.addEventListener("click", function (e) {
    mainFinancialRatiosTabsArray.forEach((ele) => {
      ele.classList.remove("active");
    });
    e.currentTarget.classList.add("active");
    FinancialsRatiosDivsArray.forEach((div) => {
      div.style.display = "none";
    });
    document.querySelector(e.currentTarget.dataset.cont).style.display =
      "block";
  });
});
/* End Of Main Financial statement tabs */

/* fs-annual-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_annual_Parent = $(".fr-annual .scroll-container");
  //Start the scrolling process
  $(".fr-annual-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fr-annual-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fr-annual .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fr-annual-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_annual_Parent.scrollLeft() + scrollStep * modifier;

        fs_annual_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fr-annual-scroll scroll */

/* fr-quarter-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_quarter_Parent = $(".fr-quarter .scroll-container");
  //Start the scrolling process
  $(".fr-quarter-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fr-quarter-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fr-quarter .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fr-quarter-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_quarter_Parent.scrollLeft() + scrollStep * modifier;

        fs_quarter_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fr-quarter-scroll scroll */

/* fr-interim-scroll scroll */
(function () {
  var scrollHandle = 0,
    scrollStep = 2,
    fs_interim_Parent = $(".fr-interim .scroll-container");
  //Start the scrolling process
  $(".fr-interim-panner").on("mouseenter touchstart", function () {
    var data = $(this).data("scrollModifier"),
      direction = parseInt(data, 10);
    $(this).addClass("active-scroll");
    startScrolling(direction, scrollStep);
  });
  //Kill the scrolling
  $(".fr-interim-panner").on("mouseleave", function () {
    stopScrolling();
    $(this).removeClass("active-scroll");
  });
  $(".fr-interim .scroll-container").on(
    "touchstart click mouseenter",
    function () {
      stopScrolling();
      $(".fr-interim-panner").removeClass("active-scroll");
    }
  );
  //Actual handling of the scrolling
  function startScrolling(modifier, step) {
    if (scrollHandle === 0) {
      scrollHandle = setInterval(function () {
        var newOffset = fs_interim_Parent.scrollLeft() + scrollStep * modifier;

        fs_interim_Parent.scrollLeft(newOffset);
      }, 10);
    }
  }

  function stopScrolling() {
    clearInterval(scrollHandle);
    scrollHandle = 0;
  }
})();
/* end of fr-interim-scroll scroll */

/////////////////////////////// End Of Financial Statemenets Tab //////////////////////////////////////


/* accordion menu */
function showHideChild(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");

    $("#btn" + fieldID).data("childviewstatus", "close");

    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-parentid='" + fieldID + "']").each(function () {
      $(this).show();
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}

function showHideSubStatement(fieldID) {
  var openAccordians =
    JSON.parse(sessionStorage.getItem("openAccordians")) || [];
  if ($("#btn" + fieldID).data("childviewstatus") == "open") {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      $(this).hide();
    });

    $("#tr" + fieldID)
      .removeClass("fTrOpen")
      .addClass("fTrClose");
    $("#btn" + fieldID)
      .removeClass("fOpen")
      .addClass("fClose");
    $("#btn" + fieldID).data("childviewstatus", "close");
    openAccordians = jQuery.grep(openAccordians, function (acordian) {
      return acordian != "#btn" + fieldID;
    });
    sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
  } else {
    $("tr[data-SubStatatementID='" + fieldID + "']").each(function () {
      if ($(this).data("ischildelement") == "no") {
        $(this).show();
      }
      if ($(this).data("haschildelementdata") == "yes") {
        var fldID = $(this).attr("id");
        fldID = fldID.substring(2);
        $("#tr" + fldID)
          .removeClass("fTrOpen")
          .addClass("fTrClose");
        $("#btn" + fldID)
          .removeClass("fOpen")
          .addClass("fClose");
        $("#btn" + fldID).data("childviewstatus", "close");
      }
    });

    $("#tr" + fieldID)
      .removeClass("fTrClose")
      .addClass("fTrOpen");
    $("#btn" + fieldID)
      .removeClass("fClose")
      .addClass("fOpen");

    $("#btn" + fieldID).data("childviewstatus", "open");
    if (openAccordians.indexOf("#btn" + fieldID) == -1) {
      openAccordians.push("#btn" + fieldID);
      sessionStorage.setItem("openAccordians", JSON.stringify(openAccordians));
    }
  }
  return false;
}


jQuery(document).ready(function() {
  jQuery(".main-table").clone(true).appendTo('#table-scroll').addClass('clone');   
});

/*    End Of Financial Ratios Page  */
